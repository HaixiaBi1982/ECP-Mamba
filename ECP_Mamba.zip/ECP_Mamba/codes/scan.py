import math
import torch


def zigzag_row_positive_scan(tensor):
    b, c, s, _ = tensor.size()
    flattened = tensor.flatten(-2)
    zigzag_idx = torch.arange(s*s).view(s, s)
    if s <= 1:
        raise Exception("the size of W or H should be larger than 1")
    if 2 <= s <= 3:
        zigzag_idx[1, :] = zigzag_idx[1, :].flip(0)
    else:
        zigzag_idx[1::2, :] = zigzag_idx[1::2, :].flip(1)
    output_idx = zigzag_idx.flatten()
    return flattened[..., output_idx]


''' define  : diagonal_scan
    input   : tensor, shape: (b, c, row, col)
    output  : tensor, shape: (b, c, row * col)
    variable: k 列表序号, i 行序号, j 列序号, row 行数, col 列数
    method  : 假设 (0, 0) 在左上角, (row-1, col-1) 在右下角的情况. 考虑非边界的情况, 只有右上/左下两个方向.
              以从 (0, 0) 先向右(下)为例, 则会有 i+j 为偶数时右上(左下)前进, 为奇数时左下(右上)的情况前进.
              如果遇到边界, 某个方向收到限制, 移动允许的直线方向'''
def zigzag_diagonal_positive_scan(data):
    b, c, w, h = data.size()
    output = torch.zeros_like(data).flatten(-2)
    k = 0
    i = 0
    j = 0

    while i < w and j < h and k < w * h:
        output[..., k] = data[..., i, j]
        k = k + 1
        # i + j 为偶数, 右上移动. 下面情况是可以合并的, 但是为了方便理解, 分开写
        if (i + j) % 2 == 0:
            # 右边界超出, 则向下
            if (i - 1) in range(w) and (j + 1) not in range(h):
                i = i + 1
            # 上边界超出, 则向右
            elif (i - 1) not in range(w) and (j + 1) in range(h):
                j = j + 1
            # 上右边界都超出, 即处于右上顶点的位置, 则向下
            elif (i - 1) not in range(w) and (j + 1) not in range(h):
                i = i + 1
            else:
                i = i - 1
                j = j + 1
        # i + j 为奇数, 左下移动
        elif (i + j) % 2 == 1:
            # 左边界超出, 则向下
            if (i + 1) in range(w) and (j - 1) not in range(h):
                i = i + 1
            # 下边界超出, 则向右
            elif (i + 1) not in range(w) and (j - 1) in range(h):
                j = j + 1
            # 左下边界都超出, 即处于左下顶点的位置, 则向右
            elif (i + 1) not in range(w) and (j - 1) not in range(h):
                j = j + 1
            else:
                i = i + 1
                j = j - 1

    return output

def raster_diagonal_positive_scan(data):
    b, c, w, h = data.size()
    output = torch.zeros_like(data).flatten(-2)
    k = 0
    for d in range(w + h - 1):
        start_row = max(0, d - w + 1)
        end_row = min(d, h - 1) + 1
        for i in range(start_row, end_row):
            j = d - i
            if j < w and i < h:
                output[..., k] = data[..., i, j]
                k = k + 1
    return output

def spiral_positive_scan(data):
    b, c, m, n = data.size()
    row = col = count = 0
    matrix = torch.zeros([m, n], dtype=torch.long)
    output = torch.zeros_like(data.flatten(-2))

    while count < m * n:  # 总共m*n个数
        while row < m and matrix[row, col] != -1:  # 向下取数
            matrix[row, col] = -1  # 将去过的位置置为-1
            output[..., count] = data[..., row, col]
            row += 1
            count += 1
        row -= 1  # 上个循环结束后row的值为m,需要减1，否则越界
        col += 1  # 列值加1，因为第零列在上个循环已经输出，往右推一行
        while col < n and matrix[row, col] != -1:  # 向右取数
            matrix[row, col] = -1  # 将去过的位置置为-1
            output[..., count] = data[..., row, col]
            col += 1
            count += 1
        row -= 1  # 往上推一行
        col -= 1  # 上个循环使列值为n
        while row >= 0 and matrix[row, col] != -1:  # 向上取数
            matrix[row, col] = -1  # 将去过的位置置为-1
            output[..., count] = data[..., row, col]
            row -= 1
            count += 1
        row += 1  # 上个循环使行值为-1
        col -= 1  # 往左推一行
        while col >= 0 and matrix[row, col] != -1:  # 向左取数
            matrix[row, col] = -1  # 将去过的位置置为-1
            output[..., count] = data[..., row, col]
            col -= 1
            count += 1
        col += 1  # 上个循环使列值为-1
        row += 1  # 向下推一行

    return output

def unfold_tensor(tensor_4d, order):
    B, C, S, _ = tensor_4d.size()

    if order == 'raster_row_positive':
        scanned_tensor = tensor_4d.flatten(-2)
    elif order == 'raster_row_negative':
        scanned_tensor = tensor_4d.flatten(-2).flip(-1)
    elif order == 'raster_column_positive':
        scanned_tensor = torch.rot90(tensor_4d, 1, [-2, -1]).flip(-2).flatten(2)
    elif order == 'raster_column_negative':
        scanned_tensor = torch.rot90(tensor_4d, 1, [-2, -1]).flip(-2).flatten(2).flip(-1)
    elif order == 'raster_diagonal_positive':
        scanned_tensor = raster_diagonal_positive_scan(tensor_4d)
    elif order == 'raster_diagonal_negative':
        scanned_tensor = raster_diagonal_positive_scan(tensor_4d).flip(-1)

    elif order == 'zigzag_row_positive':
        scanned_tensor = zigzag_row_positive_scan(tensor_4d)
    elif order == 'zigzag_row_negative':
        scanned_tensor = zigzag_row_positive_scan(torch.rot90(tensor_4d, 2, [-2, -1]))
    elif order == 'zigzag_column_positive':
        scanned_tensor = zigzag_row_positive_scan(torch.rot90(tensor_4d.flip(-2), 3, [-2, -1]))
    elif order == 'zigzag_column_negative':
        scanned_tensor = zigzag_row_positive_scan(torch.rot90(tensor_4d.flip(-2), 1, [-2, -1]))
    elif order == 'zigzag_diagonal_positive':
        scanned_tensor = zigzag_diagonal_positive_scan(tensor_4d)
    elif order == 'zigzag_diagonal_negative':
        scanned_tensor = zigzag_diagonal_positive_scan(torch.rot90(tensor_4d, 2, [-2, -1]))

    elif order == 'spiral_positive':
        scanned_tensor = spiral_positive_scan(tensor_4d)
    elif order == 'spiral_negative':
        scanned_tensor = spiral_positive_scan(tensor_4d).flip(-1)

    else:
        raise Exception(f"order {order} not supported")
    return scanned_tensor


def random_scan(tensor_3d, order):
    B, SS, C = tensor_3d.size()
    assert math.sqrt(SS).is_integer(), math.sqrt(SS)
    S = int(math.sqrt(SS))
    tensor_4d = tensor_3d.transpose(1, 2).view(B, C, S, S)

    if order == 'raster_row':
        scanned_tensor_f = tensor_4d.flatten(-2)
        # scanned_tensor_b = tensor_4d.flatten(-2).flip(-1)
    elif order == 'raster_column':
        scanned_tensor_f = torch.rot90(tensor_4d, 1, [-2, -1]).flip(-2).flatten(2)
        # scanned_tensor_b = torch.rot90(tensor_4d, 1, [-2, -1]).flip(-2).flatten(2).flip(-1)
    elif order == 'raster_diagonal':
        scanned_tensor_f = raster_diagonal_positive_scan(tensor_4d)
        # scanned_tensor_b = raster_diagonal_positive_scan(tensor_4d).flip(-1)

    elif order == 'zigzag_row':
        scanned_tensor_f = zigzag_row_positive_scan(tensor_4d)
        # scanned_tensor_b = zigzag_row_positive_scan(torch.rot90(tensor_4d, 2, [-2, -1]))
    elif order == 'zigzag_column':
        scanned_tensor_f = zigzag_row_positive_scan(torch.rot90(tensor_4d.flip(-2), 3, [-2, -1]))
        # scanned_tensor_b = zigzag_row_positive_scan(torch.rot90(tensor_4d.flip(-2), 1, [-2, -1]))
    elif order == 'zigzag_diagonal':
        scanned_tensor_f = zigzag_diagonal_positive_scan(tensor_4d)
        # scanned_tensor_b = zigzag_diagonal_positive_scan(torch.rot90(tensor_4d, 2, [-2, -1]))

    elif 'spiral' in order:
        scanned_tensor_f = spiral_positive_scan(torch.rot90(tensor_4d.flip(-2), 3, [-2, -1]))
    else:
        raise Exception(f"order {order} not supported")

    # (B, C, N) --> (B, N, C)
    return scanned_tensor_f.transpose(1, 2)


if __name__ == "__main__":

    size = 3
    # 创建一个4D张量
    tensor_2d = torch.arange(1, size**2+1)
    tensor_3d = tensor_2d.view(1, 1, size * size).repeat(2, 3, 1).transpose(1, 2)  # 这里重复2次B维度，3次C维度
    print(tensor_3d)
    print(tensor_3d.shape)

    # tensor_4d = tensor_3d.view(2, 3, size, size)
    # print(tensor_4d.shape)
    # print(tensor_4d)

    # # 设定展开顺序
    # scan_mode = "raster"  # raster, zigzag
    # scan_axis = "column" # row, column, diagonal
    # scan_direction = "negative" # positive, negative"
    #
    # # 展开方式
    # scan = '_'.join([scan_mode, scan_axis, scan_direction])
    # print(scan)

    for scan_mode in ["spiral"]:
        # 展开张量
        unfolded_tensor = random_scan(tensor_3d, scan_mode)
        print(unfolded_tensor.shape)
        print(unfolded_tensor)