import warnings

from codes import utils

warnings.filterwarnings('ignore')

import argparse
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "1"

import datetime
import torch
from torch.utils.data import DataLoader
from config import configurations

from dataset_preparing.dataset_def import DataSet
from codes.utils import seed_torch, one_hot_PolyLoss
from codes.test_acc_in_labeled_data import get_confusion_matrix_on_whole_lables, \
    get_classification_result_on_whole_dataset
from dataset_preparing.dataset_aug import rotate90, rotate180, rotate270, HorizontalFlip, HFlip_rotate90, \
    HFlip_rotate180, HFlip_rotate270

# Downstream classification settings
parser = argparse.ArgumentParser(description='Configurations for ECP_Mamba: Classification Fine-tuning')

# PolSAR dataset setting
parser.add_argument('--data_name', default='FlveoBig', type=str,
                    help='Please specify the PolSAR training dataset from: FlveoBig, Flevo1991, Oberpfa, San900690.')
parser.add_argument('--if_complex_data', default=False, type=bool, help='Whether to use complex data.')
parser.add_argument('--image_size', default=[16, 32], type=int, help='Image Size of patch views.')
parser.add_argument('--batch_size', default=128, type=int, help='batch_size.')
parser.add_argument('--sampling_rate', default=0.2 / 100, type=int,
                    help='0 < sampling_rate < 1: sampling from annotated patches for training. '
                         '1 < sampling_rate: sampling data num of each class. '
                         'Default: '
                         'sampling_rate=0.2% if data_name == FlveoBig or Flevo1991 or Oberpfa'
                         'else sampling_rate=0.05% if data_name == San900690')

# training setting
parser.add_argument('--creat_new_network', type=bool, default=False,
                    help='Whether to use a pre-trained network (default: False)')
parser.add_argument('--arch', default='cross-vim', type=str,
                    choices=['vim', 'multi-vim', 'cross-vim'],
                    help='type of model  (default: the proposed Multi-scale Efficient Mamba)')
parser.add_argument('--model_type', type=str, default='vim',
                    choices=['vim'],
                    help='type of network architecture: VisionMamba or VisionTransformer (default: vim)')
parser.add_argument('--max_epochs', type=int, default=100,
                    help='maximum number of epochs to train (default: 100)')
parser.add_argument('--lr', type=float, default=1e-3,
                    help='learning rate (default: 0.001)')
parser.add_argument('--reg', type=float, default=1e-5,
                    help='weight decay (default: 1e-5)')
parser.add_argument('--seed', type=int, default=42,
                    help='random seed for reproducible experiment (default: 42)')
parser.add_argument('--pretrained_result_dir', type=str, default="pretrain_results"
                    , help='Path to save codes models and checkpoints.')
parser.add_argument('--load_dir', default="./pretrain_results", type=str,
                    help='Path to pretrained logs and checkpoints.')
parser.add_argument('--results_dir', default='./classification_results',
                    help='results directory (default: ./classification_results)')

parser.add_argument('--early_stopping', action='store_true', default=False, help='enable early stopping')
parser.add_argument('--drop_out', action='store_true', default=False, help='enable dropout (p=0.25)')

parser.add_argument('--opt', type=str, choices=['adam', 'adamw', 'nadam'], default='adamw')
parser.add_argument('--loss_type', type=str, choices=['CrossEntropy', 'Poly'], default='Poly',
                    help='type of loss function (default: PolyLoss)')

args = parser.parse_args()
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def main(net, train_dataset, args):
    # create results directory if necessary
    if not os.path.isdir(args.results_dir):
        os.mkdir(args.results_dir)

    train_dataloader = DataLoader(train_dataset, args.batch_size, shuffle=True, num_workers=8)

    if args.loss_type=='CrossEntropy':
        loss_function = torch.nn.CrossEntropyLoss()
    elif args.loss_type=='Poly':
        loss_function = one_hot_PolyLoss(num_classes=train_dataset.class_num)
    else:
        loss_function = None

    if args.opt == 'adam':
        optimizer = torch.optim.Adam(net.parameters(), lr=args.lr)
    elif args.opt == 'adamw':
        optimizer = torch.optim.AdamW(net.parameters(), lr=args.lr)
    elif args.opt == 'nadam':
        optimizer = torch.optim.NAdam(net.parameters(), lr=args.lr)
    else:
        optimizer = None

    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.max_epochs, eta_min=0)
    seed_torch(args.seed)

    all_loss = []
    all_acc =[]
    all_lr = []
    net.train().to(device)
    for e in range(args.max_epochs):
        total_loss = 0
        total_acc = 0
        batch_in_epoch = 0
        for imgs, targets in train_dataloader:
            targets = targets.to(device)
            for i in range(len(imgs)):
                imgs[i] = imgs[i].to(device)

            if args.arch=="cross-vim" or args.arch=="multi-vim":
                output = net(imgs)
            else:
                output = net(imgs[0])

            if not args.if_complex_data:
                loss = loss_function(output, targets)
            else:
                loss_real = loss_function(output.real, targets.real)
                loss_imag = loss_function(output.imag, targets.real)
                loss = (loss_real + loss_imag) / 2
            total_loss += loss.item()

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if not args.if_complex_data:
                prediction = torch.argmax(output, dim=1)
                acc = (prediction == abs(targets).argmax(1)).sum().item()
            else:
                prediction_real = torch.argmax(output.real, dim=1)
                prediction_imag = torch.argmax(output.imag, dim=1)
                acc_r = (prediction_real == abs(targets).argmax(1)).sum().item()
                acc_i = (prediction_imag == abs(targets).argmax(1)).sum().item()
                acc = acc_r

            total_acc += acc
            batch_in_epoch = batch_in_epoch + 1

        lr = optimizer.param_groups[0]['lr']
        all_lr.append(lr)
        all_loss.append(total_loss / batch_in_epoch)
        all_acc.append(total_acc / len(train_dataset))

        if (e + 1) % 1 == 0:
            # print("time" + datetime.datetime.now().strftime('%Y-%m-%d-%H_%M_%S'))
            print("Epoch {}/{}: Lr {}; BatchLoss {}; TrainAcc {:.2%}; ".format(e + 1,
                                                                              args.max_epochs,
                                                                              lr,
                                                                              total_loss / batch_in_epoch,
                                                                              total_acc / len(train_dataset)))
        scheduler.step()

    draw_training_curve = False
    if draw_training_curve:
        from matplotlib import pyplot as plt
        # Draw Training Pictures
        all_epochs = [i+1 for i in range(args.max_epochs)]
        plt.figure(figsize=(12, 12))
        plt.subplot(2, 2, 1), plt.plot(all_epochs, all_lr, ".-"), plt.xlabel("Epoches"), plt.ylabel(
            "Learning Rate"), plt.title(
            "Learning Rate")
        plt.subplot(2, 2, 2), plt.plot(all_epochs, all_loss, ".-"), plt.xlabel("Epoches"), plt.ylabel(
            "Train Loss"), plt.title(
            "Train Loss")
        plt.subplot(2, 2, 3), plt.plot(all_epochs, all_acc, ".-"), plt.xlabel("Epoches"), plt.ylabel(
            "Train Accuracy"), plt.title(
            "Train Accuracy")
        plt.show()
    return net



if __name__ == "__main__":
    seed_torch(args.seed)

    training_settings = {
        'creat_new_network': args.creat_new_network,
        'arch': args.arch,
        'max_epochs': args.max_epochs,
        'results_dir': args.results_dir,
        'lr': args.lr,
        'reg': args.reg,
        'seed': args.seed,
        'model_type': args.model_type,
        "use_drop_out": args.drop_out,
        'loss_type': args.loss_type,
        'opt': args.opt,
    }

    dataset_settings = {
        'data_name': args.data_name,
        'if_complex_data': args.if_complex_data,
        'image_size': args.image_size,
        'sampling_rate': args.sampling_rate,
        'batch_size': args.batch_size,
    }

    # Setting PolSAR Dataset
    print("################# Dataset Settings ###################")
    for key, val in dataset_settings.items():
        print("{}:  {}".format(key, val))

    # augmentation_list = []
    augmentation_list = [rotate90, rotate180, rotate270, HorizontalFlip, HFlip_rotate90, HFlip_rotate180, HFlip_rotate270]
    print(f"len(augmentation_list): {len(augmentation_list)}")

    training_dataset = DataSet(
        dataset_path="../benchmark_dataset/" + args.data_name,
        window_size_list=args.image_size,
        std=True,
        return_position=False,
        delete_0=True,
        complex_data=args.if_complex_data,
        sampling_rate=args.sampling_rate,
        augmentation_list=augmentation_list,
        seed=args.seed,
    )
    # mean, std = training_dataset.__get_mean_and_std__()
    class_num = training_dataset.class_num
    channels = 6 if args.if_complex_data else 9

    if not os.path.isdir(args.results_dir):
        os.mkdir(args.results_dir)

    time = datetime.datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    args.results_dir = os.path.join(args.results_dir, time + '_seed{}'.format(args.seed))
    if not os.path.isdir(args.results_dir):
        os.mkdir(args.results_dir)

    with open(args.results_dir + '/experiment_setting.txt', 'w') as f:
        print(training_settings, file=f)
    f.close()

    print("################# Training Settings ###################")
    for key, val in training_settings.items():
        print("{}:  {}".format(key, val))

    # Loading Network
    config = configurations[args.arch]
    print("################# Network Settings ###################")
    for key, val in config.items():
        print("{}:  {}".format(key, val))


    if args.model_type == 'vim':
        if args.arch == "vim":
            from codes.vim.models_mamba import VisionMamba
            network = VisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
        elif args.arch == "multi-vim":
            from codes.vim.models_cross_mamba import CrossVisionMamba
            network = CrossVisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
        elif args.arch == "cross-vim":
            from codes.vim.models_cross_mamba import CrossVisionMamba
            network = CrossVisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
        else:
            network = None
            assert 0
    else:
        network = None
        assert 0

    # Whether to use a pre-trained network
    if not args.creat_new_network:
        load_path = os.path.join(args.load_dir, args.data_name, 'checkpoint.pth')
        print(f'Load pretrained model from: {load_path}')
        pretrain_dict = torch.load(load_path, map_location=torch.device('cpu'))
        student_dict = pretrain_dict['student']

        if args.arch == "cross-vim":
            # load checkpoint to student branch: patch_embed, mamba_blocks, norm_f
            stu_patchify_dict, stu_mamba_dict, stu_norm_dict = (
                network.patch_embed[0].state_dict(),
                network.branches[0].state_dict(),
                network.norm_f[0].state_dict(),
            )
            # print(stu_patchify_dict.keys(), stu_norm_dict.keys(), pretrain_dict['student'].keys())
            stu_patchify_dict = utils.load_filtered_dicts(target_dict=stu_patchify_dict, source_dict=pretrain_dict['student'], name_list=['patch_embed'])
            stu_mamba_dict = utils.load_filtered_dicts(target_dict=stu_mamba_dict, source_dict=pretrain_dict['student'],)
            stu_norm_dict = utils.load_filtered_dicts(target_dict=stu_norm_dict, source_dict=pretrain_dict['student'], name_list=['norm_f'])
            network.patch_embed[0].load_state_dict(stu_patchify_dict)
            network.branches[0].load_state_dict(stu_mamba_dict)
            network.norm_f[0].load_state_dict(stu_norm_dict)

            network.cls_token[0] = pretrain_dict['student']['module.backbone.cls_token']
            network.pos_embed[0] = pretrain_dict['student']['module.backbone.pos_embed']

            # load checkpoint to teacher branch
            tea_patchify_dict, tea_mamba_dict, tea_norm_dict = (
                network.patch_embed[1].state_dict(),
                network.branches[1].state_dict(),
                network.norm_f[1].state_dict(),
            )
            tea_patchify_dict = utils.load_filtered_dicts(tea_patchify_dict, pretrain_dict['teacher'], name_list=['patch_embed'])
            tea_mamba_dict = utils.load_filtered_dicts(tea_mamba_dict, pretrain_dict['teacher'])
            tea_norm_dict = utils.load_filtered_dicts(tea_norm_dict, pretrain_dict['teacher'], name_list=['norm_f'])
            network.patch_embed[1].load_state_dict(tea_patchify_dict)
            network.branches[1].load_state_dict(tea_mamba_dict)
            network.norm_f[1].load_state_dict(tea_norm_dict)
            network.cls_token[1] = pretrain_dict['teacher']['backbone.cls_token']
            network.pos_embed[1] = pretrain_dict['teacher']['backbone.pos_embed']

            network = network.to(device)
        else:
            network.load_state_dict(pretrain_dict['student']).to(device)

    network = main(network, training_dataset, args)

    # save checkpoint
    # saving_time = datetime.datetime.now().strftime('%Y_%m_%d-%H_%M_%S')
    save_dict = {
        'network': network.state_dict(),
        'args': args,
    }
    torch.save(save_dict, args.results_dir + "/{}.pth".format('checkpoint'))  # 保存网络模型
    print("network & args are saved in {}.".format(args.results_dir + "/{}.pth".format('checkpoint')))

    # Evaluate the classification accuracy on the whole labeled data.
    test_dataset = DataSet(
        dataset_path="../benchmark_dataset/" + args.data_name,
        window_size_list=args.image_size,
        std=True,
        return_position=False,
        delete_0=True,
        complex_data=args.if_complex_data,
        sampling_rate=1.0,
        seed=args.seed,
    )
    get_confusion_matrix_on_whole_lables(test_net=network.eval(),
                                         full_dataset=test_dataset,
                                         dtype_is_complex=args.if_complex_data,
                                         device=device, save_path=args.results_dir,
                                         arch=args.arch,)


    # Compute the classification result on the whole data.
    test_dataset = DataSet(
        dataset_path="../benchmark_dataset/" + args.data_name,
        window_size_list=args.image_size,
        std=True,
        return_position=True,
        delete_0=False,
        complex_data=args.if_complex_data,
        sampling_rate=1.0,
        seed=args.seed,
    )
    get_classification_result_on_whole_dataset(test_net=network.eval(),
                                               full_dataset=test_dataset,
                                               dtype_is_complex=args.if_complex_data,
                                               device=device, save_path=args.results_dir,
                                               arch=args.arch,)
    print("End script.")



