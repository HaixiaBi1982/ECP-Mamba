# Causal depthwise conv1d in CUDA with a PyTorch interface
