import numpy as np
import torch
from torch.utils.data import DataLoader
import pandas as pd
import seaborn as sns
from matplotlib import pyplot as plt
from colormap import rgb2hex


def kappa_cal(matrix):
    n = np.sum(matrix)
    sum_po = 0
    sum_pe = 0
    for i in range(len(matrix[0])):
        sum_po += matrix[i][i]
        row = np.sum(matrix[i, :])
        col = np.sum(matrix[:, i])
        sum_pe += row * col
    po = sum_po / n
    pe = sum_pe / (n * n)
    # print(po, pe)
    return (po - pe) / (1 - pe)


def get_confusion_matrix_on_whole_lables(
    test_net,
    full_dataset,
    dtype_is_complex=False,
    device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
    save_path=None,
    arch="cross-vim",):

    print("=" * 30)
    print("Test on labeled dataset:")

    dataloader = DataLoader(full_dataset, 128, shuffle=True, num_workers=1)
    total_acc = 0
    class_num = full_dataset.class_num
    prediction_matrix = np.zeros([class_num, class_num])
    _, ground_truth = full_dataset.__get_whole_image__()

    for i, (input, targets) in enumerate(dataloader):
        # input, targets = input.to(device), targets.to(device)
        targets = targets.to(device)
        input = [input[j].to(device) for j in range(len(input))]

        if arch == "cross-vim" or arch == "multi-vit-t" or arch=="multi-vim":
            input = input
        else:
            input = input[0]

        with torch.no_grad():
            output = test_net(input)

            if dtype_is_complex:
                prediction = torch.argmax(output.real + output.imag, dim=1)
                acc = (prediction == abs(targets).argmax(1)).sum().item()
            else:
                prediction = torch.argmax(output, dim=1)
                acc = (prediction == abs(targets).argmax(1)).sum().item()

        total_acc = total_acc + acc
        for prediction, GT in zip(prediction, torch.argmax(abs(targets), dim=1)):
            prediction_matrix[int(GT), int(prediction)] += 1
        print("\rTesting...{:.2%} test_data_amount:{}".format((i+1) / len(dataloader), len(full_dataset)), end="")
    print("\n")

    OA = total_acc / len(full_dataset)
    classes_num = np.sum(prediction_matrix, 1)

    AA = 0
    for i in range(class_num):
        print("class{}: {:.2%} {}/{}".format(i, prediction_matrix[i, i] / np.sum(prediction_matrix, 1)[i],
                                             int(prediction_matrix[i, i]), int(np.sum(prediction_matrix, 1)[i])))
        AA += prediction_matrix[i, i] / np.sum(prediction_matrix, 1)[i]
        for j in range(class_num):
            prediction_matrix[i, j] = prediction_matrix[i, j] / classes_num[i]
    AA = AA / class_num
    Kappa = kappa_cal(prediction_matrix)

    if save_path is not None:        # save prediction matrix
        np.savetxt(fname=save_path + "/confusion_matrix.txt", X=100 * prediction_matrix, fmt="%.2f")

    # Draw a heat map.
    plt.figure(dpi=300)
    data = pd.DataFrame(100 * prediction_matrix)
    plot = sns.heatmap(data, square=False, annot=True, fmt='.2f', cmap="Blues",
                       vmax=100.00, vmin=0.00,
                       annot_kws={'size':6},
                       )
    # Resize the font
    plt.xticks(fontsize=7)
    plt.yticks(fontsize=7)
    plt.ylabel("True label", fontsize=10)
    plt.xlabel("Predicted label", fontsize=10)
    # setting color bar
    cbar = plot.collections[0].colorbar
    cbar.ax.tick_params(labelsize=7)
    plt.title(save_path +"\nconfusion_matrix.png\n OA={:.2%},AA={:.2%},Kappa={:.2%}\n".format( OA, AA,
                                                                                               Kappa), fontsize='small')
    if save_path is not None:
        plt.savefig(save_path + "/confusion_matrix.png")
    plt.show()

    print("=" * 30)
    print("Overall Accuracy:{:.2%}\nAverage Accuracy:{:.2%}\nKappa:{:.2%}".format(OA, AA, Kappa))
    print("=" * 30)


def get_classification_result_on_whole_dataset(
        test_net,
        full_dataset,
        dtype_is_complex=False,
        device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
        save_path=None,
        arch="cross-vim",):

    print("=" * 30)
    print("Test on whole dataset:")
    dataloader = DataLoader(full_dataset, 128, shuffle=True, num_workers=8)
    _, ground_truth = full_dataset.__get_whole_image__()
    w, h = ground_truth.shape[0], ground_truth.shape[1]
    classification_result = np.zeros([w, h], dtype=int)

    for i, (input, targets, position) in enumerate(dataloader):
        input = [input[j].to(device) for j in range(len(input))]

        if arch == "cross-vim" or arch == "multi-vit-t" or arch=="multi-vim":
            input = input
        else:
            input = input[0]

        with torch.no_grad():
            output = test_net(input)
            if dtype_is_complex:
                prediction = torch.argmax(output.real + output.imag, dim=1)
            else:
                prediction = torch.argmax(output, dim=1)

        for ii in range(prediction.shape[0]):
            p = position[ii, :]
            classification_result[p[0], p[1]] = prediction[ii].cpu().detach().numpy().astype(int)
        print("\rTesting...{:.2%} test_data_amount:{}".format((i + 1) / len(dataloader), len(full_dataset)), end="")
    print("\n")

    # Draw Classification Result
    dpi = 100
    fig = plt.figure(frameon=False)
    fig.set_size_inches(w * 2.0 / dpi, h * 2.0 / dpi)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    ax.xaxis.set_visible(False)
    ax.yaxis.set_visible(False)
    fig.add_axes(ax)
    ax.set_title("dataset_path: {}".format(full_dataset.dataset_path))
    ax.imshow(ground_truth)
    y = data_to_colormap2(classification_result, full_dataset.dataset_path)
    image = np.reshape(y, (w, h, 3))
    image = np.rot90(image, k=1)
    plt.imshow(image)
    plt.savefig(save_path + "/classification_result.png")
    plt.show()
    np.save(save_path + '/classification_result.npy', classification_result)


def data_to_colormap2(classification_result, dataset_path):
    x_list = classification_result.reshape((-1,))
    y = np.zeros((x_list.shape[0], 3))

    if "FlveoBig" in dataset_path:
        colors_list = \
            ['white', rgb2hex(0, 0, 225), 'darkred', 'indigo',
             'red', 'm', 'forestgreen', 'darkgoldenrod', 'lime',
             'orange', 'cyan', rgb2hex(220, 208, 255),
             'pink', 'navajowhite', 'yellow', 'lightgreen']
    elif "Flevo1991" in dataset_path:
        colors_list = ['white',
                       rgb2hex(255, 128, 0), rgb2hex(138, 42, 166), rgb2hex(0, 0, 255),
                       rgb2hex(255, 0, 0), rgb2hex(120, 178, 215), rgb2hex(0, 102, 205),
                       rgb2hex(251, 232, 45), rgb2hex(0, 255, 0), rgb2hex(204, 102, 255),
                       rgb2hex(0, 204, 102), rgb2hex(204, 255, 204), rgb2hex(204, 0, 102),
                       rgb2hex(255, 204, 204), rgb2hex(102, 0, 204)]
    elif "Oberpfa" in dataset_path:
        colors_list = ['white', rgb2hex(255, 0, 0), rgb2hex(0, 255, 0), rgb2hex(255, 255, 0)]
    elif "San900690" in dataset_path:
        colors_list = [
                       'white',
                       rgb2hex(0, 0, 1, True),  # 蓝色
                       rgb2hex(0, 1, 0, True),  # 绿色
                       rgb2hex(1, 0, 1, True),  # 紫色
                       rgb2hex(1, 0, 0, True),  # 红色
                       rgb2hex(1, 1, 0, True),  # 黄色
                       ]
    else:
        assert 0, dataset_path

    for index, item in enumerate(x_list):
        item = item + 1
        y[index] = np.array(get_rgb(colors_list[item])) / 255
    return y


import matplotlib.colors as colors
def get_rgb(color_name):
    # 使用 matplotlib 的 to_rgb 函数获取颜色的 RGB 值
    rgb = colors.to_rgb(color_name)
    # 将 RGB 值转换为 0-255 的整数
    rgb = [int(x * 255) for x in rgb]
    return rgb



