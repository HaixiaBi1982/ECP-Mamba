import copy

import torch
import torch.nn as nn
from thop import profile
from thop.profile import register_hooks
from thop.utils import prRed
from thop.vision.basic_hooks import count_parameters, count_normalization
from torch.autograd import Variable

from collections import OrderedDict
import numpy as np

import codes
import mamba_ssm


def cross_vim_summary(model, input_size, batch_size=-1, device="cuda"):

	def register_hook(module):

		def hook(module, input, output):
			class_name = str(module.__class__).split(".")[-1].split("'")[0]
			module_idx = len(summary)

			m_key = "%s-%i" % (class_name, module_idx + 1)
			summary[m_key] = OrderedDict()
			summary[m_key]["input_shape"] = list(input[0].size())
			summary[m_key]["input_shape"][0] = batch_size
			if isinstance(output, (list, tuple)):
				summary[m_key]["output_shape"] = [
					[-1] + list(o.size())[1:] for o in output
				]
			else:
				summary[m_key]["output_shape"] = list(output.size())
				summary[m_key]["output_shape"][0] = batch_size

			params = 0
			# if class_name in ["Mamba"]:
			if class_name in ["Block"]:
				for name, para in module.named_parameters():
					if hasattr(para, "size"):
						params += torch.prod(torch.LongTensor(list(para.size())))
						summary[m_key]["trainable"] = para.requires_grad
			else:
				if hasattr(module, "weight") and hasattr(module.weight, "size"):
					params += torch.prod(torch.LongTensor(list(module.weight.size())))
					summary[m_key]["trainable"] = module.weight.requires_grad
				if hasattr(module, "bias") and hasattr(module.bias, "size"):
					params += torch.prod(torch.LongTensor(list(module.bias.size())))

			summary[m_key]["nb_params"] = params

		if (
			not isinstance(module, nn.Sequential)
			and not isinstance(module, nn.ModuleList)
			and not (module == model)
		):
			hooks.append(module.register_forward_hook(hook))

	device = device.lower()
	assert device in [
		"cuda",
		"cpu",
	], "Input device is not valid, please specify 'cuda' or 'cpu'"

	if device == "cuda" and torch.cuda.is_available():
		dtype = torch.cuda.FloatTensor
	else:
		dtype = torch.FloatTensor

	# multiple inputs to the network
	if isinstance(input_size, tuple):
		input_size = [input_size]

	# batch_size of 2 for batchnorm
	x = [torch.rand(2, *in_size).type(dtype) for in_size in input_size]
	# for xx in x:
	#     print(xx.shape)

	# create properties
	summary = OrderedDict()
	hooks = []

	# register hook
	model.apply(register_hook)

	# make a forward pass
	model(x)

	# remove these hooks
	for h in hooks:
		h.remove()

	print("---------------------------------------------------------------------------------------------------")
	line_new = "{:>20}  {:>20}  {:>35} {:>15}".format("Layer (type)", "Input Shape", "Output Shape", "Param #")
	print(line_new)
	print("===================================================================================================")
	total_params = 0
	total_output = 0
	trainable_params = 0
	for layer in summary:
		# input_shape, output_shape, trainable, nb_params
		line_new = "{:>20} {:>20} {:>35} {:>15}".format(
			layer,
			str(summary[layer]["input_shape"]),
			str(summary[layer]["output_shape"]),
			"{0:,}".format(summary[layer]["nb_params"]),
		)
		total_params += summary[layer]["nb_params"]
		total_output += np.prod(summary[layer]["output_shape"])
		if "trainable" in summary[layer]:
			if summary[layer]["trainable"] == True:
				trainable_params += summary[layer]["nb_params"]
		print(line_new)

	# assume 4 bytes/number (float on cuda).
	total_input_size = abs(np.prod(input_size) * batch_size * 4. / (1024 ** 2.))
	total_output_size = abs(2. * total_output * 4. / (1024 ** 2.))  # x2 for gradients
	total_params_size = abs(total_params.numpy() * 4. / (1024 ** 2.))
	total_size = total_params_size + total_output_size + total_input_size

	print("===================================================================================================")
	print("Total params: {0:,}".format(total_params))
	print("Trainable params: {0:,}".format(trainable_params))
	print("Non-trainable params: {0:,}".format(total_params - trainable_params))
	print("----------------------------------------------------------------")
	# print("Input size (MB): %0.2f" % total_input_size)
	# print("Forward/backward pass size (MB): %0.2f" % total_output_size)
	print("Network Params size (MB): %0.2f" % total_params_size)
	# print("Estimated Total Size (MB): %0.2f" % total_size)
	print("----------------------------------------------------------------")
	# return summary


def vim_summary(model, input_size, batch_size=-1, device="cuda"):

	def register_hook(module):

		def hook(module, input, output):
			class_name = str(module.__class__).split(".")[-1].split("'")[0]
			module_idx = len(summary)

			m_key = "%s-%i" % (class_name, module_idx + 1)
			summary[m_key] = OrderedDict()
			summary[m_key]["input_shape"] = list(input[0].size())
			summary[m_key]["input_shape"][0] = batch_size
			if isinstance(output, (list, tuple)):
				summary[m_key]["output_shape"] = [
					[-1] + list(o.size())[1:] for o in output
				]
			else:
				summary[m_key]["output_shape"] = list(output.size())
				summary[m_key]["output_shape"][0] = batch_size

			params = 0

			# if class_name in ["Mamba"]:
			if class_name in ["Block"]:
				for name, para in module.named_parameters():
					if hasattr(para, "size"):
						params += torch.prod(torch.LongTensor(list(para.size())))
						summary[m_key]["trainable"] = para.requires_grad
			else:
				if hasattr(module, "weight") and hasattr(module.weight, "size"):
					params += torch.prod(torch.LongTensor(list(module.weight.size())))
					summary[m_key]["trainable"] = module.weight.requires_grad
				if hasattr(module, "bias") and hasattr(module.bias, "size"):
					params += torch.prod(torch.LongTensor(list(module.bias.size())))

			summary[m_key]["nb_params"] = params

		if (
			not isinstance(module, nn.Sequential)
			and not isinstance(module, nn.ModuleList)
			and not (module == model)
		):
			hooks.append(module.register_forward_hook(hook))

	device = device.lower()
	assert device in [
		"cuda",
		"cpu",
	], "Input device is not valid, please specify 'cuda' or 'cpu'"

	if device == "cuda" and torch.cuda.is_available():
		dtype = torch.cuda.FloatTensor
	else:
		dtype = torch.FloatTensor

	# multiple inputs to the network
	if isinstance(input_size, tuple):
		input_size = [input_size]

	# batch_size of 2 for batchnorm
	x = [torch.rand(2, *in_size).type(dtype) for in_size in input_size]
	# for xx in x:
	#     print(xx.shape)

	# create properties
	summary = OrderedDict()
	hooks = []

	# register hook
	model.apply(register_hook)

	# make a forward pass
	model(*x)

	# remove these hooks
	for h in hooks:
		h.remove()

	print("---------------------------------------------------------------------------------------------------")
	line_new = "{:>20}  {:>20}  {:>35} {:>15}".format("Layer (type)", "Input Shape", "Output Shape", "Param #")
	print(line_new)
	print("===================================================================================================")
	total_params = 0
	total_output = 0
	trainable_params = 0
	for layer in summary:
		# input_shape, output_shape, trainable, nb_params
		line_new = "{:>20} {:>20} {:>35} {:>15}".format(
			layer,
			str(summary[layer]["input_shape"]),
			str(summary[layer]["output_shape"]),
			"{0:,}".format(summary[layer]["nb_params"]),
		)
		total_params += summary[layer]["nb_params"]
		total_output += np.prod(summary[layer]["output_shape"])
		if "trainable" in summary[layer]:
			if summary[layer]["trainable"] == True:
				trainable_params += summary[layer]["nb_params"]
		print(line_new)

	# assume 4 bytes/number (float on cuda).
	total_input_size = abs(np.prod(input_size[0]) * batch_size * 4. / (1024 ** 2.))
	total_output_size = abs(2. * total_output * 4. / (1024 ** 2.))  # x2 for gradients
	total_params_size = abs(total_params.numpy() * 4. / (1024 ** 2.))
	total_size = total_params_size + total_output_size + total_input_size

	print("===================================================================================================")
	print("Total params: {0:,}".format(total_params))
	print("Trainable params: {0:,}".format(trainable_params))
	print("Non-trainable params: {0:,}".format(total_params - trainable_params))
	print("----------------------------------------------------------------")
	# print("Input size (MB): %0.2f" % total_input_size)
	# print("Forward/backward pass size (MB): %0.2f" % total_output_size)
	print("Network Params size (MB): %0.2f" % total_params_size)
	# print("Estimated Total Size (MB): %0.2f" % total_size)
	print("----------------------------------------------------------------")



def vit_summary(model, input_size, batch_size=-1, device="cuda"):

	def register_hook(module):

		def hook(module, input, output):
			class_name = str(module.__class__).split(".")[-1].split("'")[0]
			module_idx = len(summary)

			m_key = "%s-%i" % (class_name, module_idx + 1)
			summary[m_key] = OrderedDict()
			summary[m_key]["input_shape"] = list(input[0].size())
			summary[m_key]["input_shape"][0] = batch_size
			if isinstance(output, (list, tuple)):
				summary[m_key]["output_shape"] = [
					[-1] + list(o.size())[1:] for o in output
				]
			else:
				summary[m_key]["output_shape"] = list(output.size())
				summary[m_key]["output_shape"][0] = batch_size

			params = 0

			if hasattr(module, "weight") and hasattr(module.weight, "size"):
				params += torch.prod(torch.LongTensor(list(module.weight.size())))
				summary[m_key]["trainable"] = module.weight.requires_grad
			if hasattr(module, "bias") and hasattr(module.bias, "size"):
				params += torch.prod(torch.LongTensor(list(module.bias.size())))

			summary[m_key]["nb_params"] = params

		if (
			not isinstance(module, nn.Sequential)
			and not isinstance(module, nn.ModuleList)
			and not (module == model)
		):
			hooks.append(module.register_forward_hook(hook))

	device = device.lower()
	assert device in [
		"cuda",
		"cpu",
	], "Input device is not valid, please specify 'cuda' or 'cpu'"

	if device == "cuda" and torch.cuda.is_available():
		dtype = torch.cuda.FloatTensor
	else:
		dtype = torch.FloatTensor

	# multiple inputs to the network
	if isinstance(input_size, tuple):
		input_size = [input_size]

	# batch_size of 2 for batchnorm
	x = [torch.rand(2, *in_size).type(dtype) for in_size in input_size]
	# for xx in x:
	#     print(xx.shape)

	# create properties
	summary = OrderedDict()
	hooks = []

	# register hook
	model.apply(register_hook)

	# make a forward pass
	model(*x)

	# remove these hooks
	for h in hooks:
		h.remove()

	print("---------------------------------------------------------------------------------------------------")
	line_new = "{:>20}  {:>20}  {:>35} {:>15}".format("Layer (type)", "Input Shape", "Output Shape", "Param #")
	print(line_new)
	print("===================================================================================================")
	total_params = 0
	total_output = 0
	trainable_params = 0
	for layer in summary:
		# input_shape, output_shape, trainable, nb_params
		line_new = "{:>20} {:>20} {:>35} {:>15}".format(
			layer,
			str(summary[layer]["input_shape"]),
			str(summary[layer]["output_shape"]),
			"{0:,}".format(summary[layer]["nb_params"]),
		)
		total_params += summary[layer]["nb_params"]
		total_output += np.prod(summary[layer]["output_shape"][0])
		if "trainable" in summary[layer]:
			if summary[layer]["trainable"] == True:
				trainable_params += summary[layer]["nb_params"]
		print(line_new)

	# assume 4 bytes/number (float on cuda).
	total_input_size = abs(np.prod(input_size) * batch_size * 4. / (1024 ** 2.))
	total_output_size = abs(2. * total_output * 4. / (1024 ** 2.))  # x2 for gradients
	total_params_size = abs(total_params.numpy() * 4. / (1024 ** 2.))
	total_size = total_params_size + total_output_size + total_input_size

	print("===================================================================================================")
	print("Total params: {0:,}".format(total_params))
	print("Trainable params: {0:,}".format(trainable_params))
	print("Non-trainable params: {0:,}".format(total_params - trainable_params))
	print("----------------------------------------------------------------")
	# print("Input size (MB): %0.2f" % total_input_size)
	# print("Forward/backward pass size (MB): %0.2f" % total_output_size)
	print("Network Params size (MB): %0.2f" % total_params_size)
	# print("Estimated Total Size (MB): %0.2f" % total_size)
	print("----------------------------------------------------------------")


def multi_vit_summary(model, input_size, batch_size=-1, device="cuda"):

	def register_hook(module):

		def hook(module, input, output):
			class_name = str(module.__class__).split(".")[-1].split("'")[0]
			module_idx = len(summary)

			m_key = "%s-%i" % (class_name, module_idx + 1)
			summary[m_key] = OrderedDict()
			summary[m_key]["input_shape"] = list(input[0].size())
			summary[m_key]["input_shape"][0] = batch_size
			if isinstance(output, (list, tuple)):
				summary[m_key]["output_shape"] = [
					[-1] + list(o.size())[1:] for o in output
				]
			else:
				summary[m_key]["output_shape"] = list(output.size())
				summary[m_key]["output_shape"][0] = batch_size

			params = 0

			if hasattr(module, "weight") and hasattr(module.weight, "size"):
				params += torch.prod(torch.LongTensor(list(module.weight.size())))
				summary[m_key]["trainable"] = module.weight.requires_grad
			if hasattr(module, "bias") and hasattr(module.bias, "size"):
				params += torch.prod(torch.LongTensor(list(module.bias.size())))

			summary[m_key]["nb_params"] = params

		if (
			not isinstance(module, nn.Sequential)
			and not isinstance(module, nn.ModuleList)
			and not (module == model)
		):
			hooks.append(module.register_forward_hook(hook))

	device = device.lower()
	assert device in [
		"cuda",
		"cpu",
	], "Input device is not valid, please specify 'cuda' or 'cpu'"

	if device == "cuda" and torch.cuda.is_available():
		dtype = torch.cuda.FloatTensor
	else:
		dtype = torch.FloatTensor

	# multiple inputs to the network
	if isinstance(input_size, tuple):
		input_size = [input_size]

	# batch_size of 2 for batchnorm
	x = [torch.rand(2, *in_size).type(dtype) for in_size in input_size]
	# for xx in x:
	#     print(xx.shape)

	# create properties
	summary = OrderedDict()
	hooks = []

	# register hook
	model.apply(register_hook)

	# make a forward pass
	model(x)

	# remove these hooks
	for h in hooks:
		h.remove()

	print("---------------------------------------------------------------------------------------------------")
	line_new = "{:>20}  {:>20}  {:>35} {:>15}".format("Layer (type)", "Input Shape", "Output Shape", "Param #")
	print(line_new)
	print("===================================================================================================")
	total_params = 0
	total_output = 0
	trainable_params = 0
	for layer in summary:
		# input_shape, output_shape, trainable, nb_params
		line_new = "{:>20} {:>20} {:>35} {:>15}".format(
			layer,
			str(summary[layer]["input_shape"]),
			str(summary[layer]["output_shape"]),
			"{0:,}".format(summary[layer]["nb_params"]),
		)
		total_params += summary[layer]["nb_params"]
		total_output += np.prod(summary[layer]["output_shape"][0])
		if "trainable" in summary[layer]:
			if summary[layer]["trainable"] == True:
				trainable_params += summary[layer]["nb_params"]
		print(line_new)

	# assume 4 bytes/number (float on cuda).
	total_input_size = abs(np.prod(input_size) * batch_size * 4. / (1024 ** 2.))
	total_output_size = abs(2. * total_output * 4. / (1024 ** 2.))  # x2 for gradients
	total_params_size = abs(total_params.numpy() * 4. / (1024 ** 2.))
	total_size = total_params_size + total_output_size + total_input_size

	print("===================================================================================================")
	print("Total params: {0:,}".format(total_params))
	print("Trainable params: {0:,}".format(trainable_params))
	print("Non-trainable params: {0:,}".format(total_params - trainable_params))
	print("----------------------------------------------------------------")
	# print("Input size (MB): %0.2f" % total_input_size)
	# print("Forward/backward pass size (MB): %0.2f" % total_output_size)
	print("Network Params size (MB): %0.2f" % total_params_size)
	# print("Estimated Total Size (MB): %0.2f" % total_size)
	print("----------------------------------------------------------------")


# Mamba: fvcore flops calculation
# =======================================
def flops_selective_scan_fn(B=1, L=256, D=768, N=16, with_D=True, with_Z=False, with_Group=True, with_complex=False):
	"""
	u: r(B D L)
	delta: r(B D L)
	A: r(D N)
	B: r(B N L)
	C: r(B N L)
	D: r(D)
	z: r(B D L)
	delta_bias: r(D), fp32

	ignores:
		[.float(), +, .softplus, .shape, new_zeros, repeat, stack, to(dtype), silu]
	"""
	assert not with_complex
	# https://github.com/state-spaces/mamba/issues/110
	flops = 9 * B * L * D * N
	if with_D:
		flops += B * D * L
	if with_Z:
		flops += B * D * L
	return flops


def selective_scan_flop_jit(module, inputs, outputs):
	B, D, L = inputs[0].size()
	N = module.A_log.size(1)
	module.total_ops += flops_selective_scan_fn(B=B, L=L, D=D, N=N, with_D=True, with_Z=False, with_Group=True)

def mamba_flops(model_type, model, shape1=(9, 16, 16), shape2=(9, 32, 32)):

	supported_ops = {
					 mamba_ssm.modules.mamba_simple.Mamba: selective_scan_flop_jit,
					 mamba_ssm.ops.triton.layernorm.RMSNorm: count_normalization,
					}

	model = copy.deepcopy(model).cuda().eval()
	input1 = torch.randn((1, *shape1), device=next(model.parameters()).device)
	input2 = torch.randn((1, *shape2), device=next(model.parameters()).device)
	# params = parameter_count(model)[""]
	if model_type == "cross_vim" or model_type == 'multi_vim':
		Gflops, _ = mamba_profile(model=model, inputs=(input1, input2), custom_ops=supported_ops)
	elif model_type == "vim":
		Gflops, _ = mamba_profile(model=model, inputs=(input1, ), custom_ops=supported_ops)
	else:
		assert 0

	del model, input1, input2
	return Gflops, _
	# return f"params {params * 4 /(1024 ** 2)} GFLOPs {sum(Gflops.values()) * 1e3}"


def mamba_profile(
	model: nn.Module,
	inputs,
	custom_ops=None,
	verbose=True,
	ret_layer_info=False,
	report_missing=False,
):
	handler_collection = {}
	types_collection = set()
	if custom_ops is None:
		custom_ops = {}
	if report_missing:
		# overwrite `verbose` option when enable report_missing
		verbose = True

	def add_hooks(m: nn.Module):
		m.register_buffer("total_ops", torch.zeros(1, dtype=torch.float64))
		m.register_buffer("total_params", torch.zeros(1, dtype=torch.float64))

		# for p in m.parameters():
		#     m.total_params += torch.DoubleTensor([p.numel()])

		m_type = type(m)
		# print(m_type)

		fn = None
		if m_type in custom_ops:
			# if defined both op maps, use custom_ops to overwrite.
			fn = custom_ops[m_type]
			if m_type not in types_collection and verbose:
				print("[INFO] Customize rule %s() %s." % (fn.__qualname__, m_type))
		elif m_type in register_hooks:
			fn = register_hooks[m_type]
			if m_type not in types_collection and verbose:
				print("[INFO] Register %s() for %s." % (fn.__qualname__, m_type))
		else:
			if m_type not in types_collection and report_missing:
				prRed(
					"[WARN] Cannot find rule for %s. Treat it as zero Macs and zero Params."
					% m_type
				)

		if fn is not None:
			handler_collection[m] = (
				m.register_forward_hook(fn),
				m.register_forward_hook(count_parameters),
			)
		types_collection.add(m_type)

	prev_training_status = model.training

	model.eval()
	model.apply(add_hooks)

	with torch.no_grad():
		# multiple inputs list to the cross_mamba
		if isinstance(inputs, tuple) and len(inputs)>=2:
			model(inputs)
		else:
			model(*inputs)

	def dfs_count(module: nn.Module, prefix="\t") -> (int, int):
		total_ops, total_params = module.total_ops.item(), 0
		ret_dict = {}
		for n, m in module.named_children():
			# if not hasattr(m, "total_ops") and not hasattr(m, "total_params"):  # and len(list(m.children())) > 0:
			#     m_ops, m_params = dfs_count(m, prefix=prefix + "\t")
			# else:
			#     m_ops, m_params = m.total_ops, m.total_params

			next_dict = {}
			if m in handler_collection and not isinstance(
				m, (nn.Sequential, nn.ModuleList)
			):
				m_ops, m_params = m.total_ops.item(), m.total_params.item()
			else:
				m_ops, m_params, next_dict = dfs_count(m, prefix=prefix + "\t")

			ret_dict[n] = (m_ops, m_params, next_dict)
			total_ops += m_ops
			total_params += m_params
		# print(prefix, module._get_name(), (total_ops, total_params))
		return total_ops, total_params, ret_dict

	total_ops, total_params, ret_dict = dfs_count(model)

	# reset model to original status
	model.train(prev_training_status)
	for m, (op_handler, params_handler) in handler_collection.items():
		op_handler.remove()
		params_handler.remove()
		m._buffers.pop("total_ops")
		m._buffers.pop("total_params")

	if model.if_use_different_scan_strategy:
		# b*c*m*n * num_of_scans * num_of_branches
		branch = len(inputs) if isinstance(inputs, tuple) and len(inputs)>=2 else 1
		scan_ops = 1*192*16*16 * len(model.scan_list) * branch
		total_ops += scan_ops

	if ret_layer_info:
		return total_ops, total_params, ret_dict
	return total_ops, total_params