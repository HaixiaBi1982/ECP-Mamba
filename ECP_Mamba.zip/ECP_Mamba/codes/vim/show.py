from random import random

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from colormap import rgb2hex



# 为每个条形指定颜色
colors = \
    [ rgb2hex(0, 0, 225), 'darkred', 'indigo',
     'red', 'm', 'forestgreen', 'darkgoldenrod', 'lime',
     'orange', 'cyan', rgb2hex(220, 208, 255),
     'pink', 'navajowhite', 'yellow', 'lightgreen']



# data_name:  FlveoBig
# sampling_rate=0.20% ori_data_num:167712 --> used_data_num:345
# class1 number: 13232 --> 27;
# class2 number: 7595 --> 16;
# class3 number: 9582 --> 20;
# class4 number: 6338 --> 13;
# class5 number: 10033 --> 21;
# class6 number: 18044 --> 37;
# class7 number: 5109 --> 11;
# class8 number: 7058 --> 15;
# class9 number: 13863 --> 28;
# class10 number: 10181 --> 21;
# class11 number: 11159 --> 23;
# class12 number: 16386 --> 33;
# class13 number: 735 --> 2;
# class14 number: 16156 --> 33;
# class15 number: 22241 --> 45;
# # 各类样本数量：
# class_list = [13232, 7595, 9582, 6338, 10033, 18044, 5109, 7058, 13863, 10181, 11159, 16386, 735, 16156, 22241]
# # Create a list of tuples containing the original list elements and their indexes
# indexed_list = [(index, value) for index, value in enumerate(class_list)]
# # Sort the indexed list in descending order based on the elements
# sorted_list = sorted(indexed_list, key=lambda x: x[1], reverse=True)
# # Iterate over the sorted indexed list and print the indexes and elements
# categories = [colors[index] for index, value in sorted_list]
# values = [value for index, value in sorted_list]
# class_index = [str(index) for index, value in sorted_list]

# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# sampled_dataset :
# Water:67
# Barley:38
# Peas:48
# Stembeans:32
# Beet:51
# Forest:91
# Bare soil:26
# Grass:36
# Rapeseed:70
# Lucerne:51
# Wheat 2:56
# Wheat:82
# Buildings:4
# Potatoes:81
# Wheat 3:112
# total:845
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# sampled_dataset+PSG+PLG后，训练数据集dataset中:
# Water:2278
# Barley:1292
# Peas:1632
# Stembeans:1088
# Beet:1734
# Forest:3094
# Bare soil:959
# Grass:1224
# Rapeseed:2380
# Lucerne:1734
# Wheat 2:1904
# Wheat:2788
# Buildings:552
# Potatoes:2754
# Wheat 3:3808
# total:29221
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# weak aug:
# Water:536(7.93%)
# Barley:304(4.50%)
# Peas:384(5.68%)
# Stembeans:256(3.79%)
# Beet:408(6.04%)
# Forest:728(10.77%)
# Bare soil:208(3.08%)
# Grass:288(4.26%)
# Rapeseed:560(8.28%)
# Lucerne:408(6.04%)
# Wheat 2:448(6.63%)
# Wheat:656(9.70%)
# Buildings:32(0.47%)
# Potatoes:648(9.59%)
# Wheat 3:896(13.25%)
# total:6760(100.00%)

# SMOTE 生成：
# Minority classes0's aug: 216
# Minority classes1's aug: 381
# Minority classes2's aug: 302
# Minority classes3's aug: 452
# Minority classes4's aug: 284
# Minority classes5's aug: 159
# Minority classes6's aug: 557
# Minority classes7's aug: 402
# Minority classes8's aug: 207
# Minority classes9's aug: 284
# Minority classes10's aug: 258
# Minority classes11's aug: 177
# Minority classes12's aug: 3619
# Minority classes13's aug: 179
# Minority classes14's aug: 129
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# values = [67, 38, 48, 32, 51, 91, 26, 36, 70, 51, 56, 82, 4, 81, 112]
# values = [2278, 1292, 1632, 1088, 1734, 3094, 959, 1224, 2380, 1734, 1904, 2788, 552, 2754, 3808]
# values = [v+s for v, s in zip(values, SMOTE_values)]
categories = colors
# %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
# base_values = [536, 304, 384, 256, 408, 728, 208, 288, 560, 408, 448, 656, 32, 648, 896]
# num = np.array(base_values)
# reciprocal_num = num.sum() / num
# SMOTE_values = np.ceil(np.multiply((reciprocal_num / reciprocal_num.sum()), num.sum()))
# # 最终每类需要增广的数目（为：倒数与所有类倒数之和的比例）
# values = [int(v+s) for v, s in zip(base_values, SMOTE_values)]
# values[-3] = 1081
# print(values)




# 设置随机种子以确保结果可复现。
np.random.seed(2)  # 你可以选择任何数字作为种子，保持结果的一致性。
# 生成一个随机数组。
values = np.random.rand(1, 15)  # 创建一个3x3的随机数组。
values[0, 0] = 1
# 打印原始数组。
print("Original values:\n", values)
# 应用softmax函数。
softmax_values = np.exp(values) / np.sum(np.exp(values), axis=1)
# 打印应用softmax后的数组。
print("Softmax values:\n", softmax_values)
values = softmax_values.tolist()[0]


# 创建条形图
fig, ax = plt.subplots()
bars = ax.bar(categories, values, color=categories)

# # 添加标题和标签
# ax.set_title('Static Bar Chart with Custom Colorbar')
# ax.set_xlabel('Categories')
# ax.set_ylabel('Values')

# 设置X轴和Y轴的上下限
ax.set_xlim(-0.5, len(categories)-0.5)  # 确保X轴的范围适合类别数量
# ax.set_ylim(0, 1)
ax.set_xticklabels([])
ax.set_yticklabels([])
# 隐藏X轴和Y轴的刻度
ax.tick_params(axis='x', which='both', bottom=False, top=False, labelbottom=False)
ax.tick_params(axis='y', which='both', left=False, right=False, labelleft=False)

# 创建一个颜色条
cmap = plt.get_cmap('viridis')  # 选择一个颜色映射
norm = plt.Normalize(vmin=min(values), vmax=max(values))
sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
sm.set_array([])  # 只需要颜色映射，不需要实际的数据

# 显示图形
plt.show()



# import matplotlib.pyplot as plt
#
# labels = ["Unlabeled", "Labeled"]
# # labels = [" ", " "]
#
# data = [768000, 167712]
# explode = [0, 0.2]  # 设置离心率
# colors = ['grey', 'skyblue']  # 设置颜色
# plt.pie(data, labels=labels, explode=explode, colors=colors, autopct='%1.1f%%',
#         textprops={'fontsize': 20})
# # 调整标签的字体大小
# plt.show()
