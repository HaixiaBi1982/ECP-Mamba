import torch
from torch import nn

def complex_dropout(input, p=0.5, training=True):
    # need to have the same dropout mask for real and imaginary part,
    mask = torch.ones(*input.shape, dtype=torch.float32, device=input.device)
    mask = torch.nn.functional.dropout(mask, p, training) * 1 / (1 - p)
    mask.type(input.dtype)
    return mask * input

class ComplexDropout(nn.Module):
    def __init__(self, p=0.5):
        super(ComplexDropout, self).__init__()
        self.p = p

    def forward(self, input):
        if self.training:
            return complex_dropout(input, self.p)
        else:
            return input

from timm.models.layers import DropPath


def drop_path(x, drop_prob: float = 0., training: bool = False, scale_by_keep: bool = True):
    """Drop paths (Stochastic Depth) per sample (when applied in main path of residual blocks).

    This is the same as the DropConnect impl I created for EfficientNet, etc networks, however,
    the original name is misleading as 'Drop Connect' is a different form of dropout in a separate paper...
    See discussion: https://github.com/tensorflow/tpu/issues/494#issuecomment-532968956 ... I've opted for
    changing the layer and argument names to 'drop path' rather than mix DropConnect as a layer name and use
    'survival rate' as the argument.

    """
    if drop_prob == 0. or not training:
        return x
    keep_prob = 1 - drop_prob
    shape = (x.shape[0],) + (1,) * (x.ndim - 1)  # work with diff dim tensors, not just 2D ConvNets
    random_tensor = x.new_empty(shape).bernoulli_(keep_prob)
    if keep_prob > 0.0 and scale_by_keep:
        random_tensor.div_(keep_prob)
    return x * random_tensor

from typing import List, Union


# a complex version of DropPath
class ComplexDropPath(nn.Module):
    """Drop paths (Stochastic Depth) per sample  (when applied in main path of residual blocks).
    """
    def __init__(self, drop_prob: float = 0., scale_by_keep: bool = True):
        super(ComplexDropPath, self).__init__()
        self.drop_prob = drop_prob
        self.scale_by_keep = scale_by_keep

    def forward(self, x):
        x = drop_path(x.real, self.drop_prob, self.training, self.scale_by_keep) +\
                drop_path(x.imag, self.drop_prob, self.training, self.scale_by_keep)
        return x

    def extra_repr(self):
        return f'drop_prob={round(self.drop_prob,3):0.3f}'


class ComplexLayerNorm(nn.Module):
    """Applies Layer Normalization over a mini-batch of inputs.

    Reference:
        Layer Normalization <https://arxiv.org/abs/1607.06450>

    Args:
        normalized_shape (int or list or torch.Size): input shape from an expected input
            of size [..., shape[0], shape[1], ..., shape[-1]].
            If a single integer is used, it is treated as a singleton list, and this
            module will normalize over the last dimension which is expected to be of
            that specific size.
        eps (float): a value added to the denominator for numerical stability.
        elementwise_affine: (bool) a boolean value that when set to ``True``, this
            module has learnable per-element affine parameters initialized to ones (for
            weights) and zeros (for biases).

    This layer uses statistics computed from input data in both training and evaluation
    modes.
    """

    def __init__(
            self,
            normalized_shape: Union[int, List[int], torch.Size],
            eps: float = 1e-05,
            elementwise_affine: bool = True,
            device=None,
            dtype=None,
    ):
        super().__init__()

        if isinstance(normalized_shape, int):
            self.normalized_shape = (normalized_shape,)
        else:
            self.normalized_shape = tuple(normalized_shape)
        self.eps = eps
        self.elementwise_affine = elementwise_affine  # 仿射变换

        opt = {"device": device, "dtype": dtype}
        if elementwise_affine:
            self.weight = nn.Parameter(torch.Tensor(*self.normalized_shape, 3))
            self.bias = nn.Parameter(torch.Tensor(*self.normalized_shape, 2))
        else:
            self.register_parameter("weight", None)
            self.register_parameter("bias", None)
        self.reset_parameters()

    def reset_parameters(self) -> None:
        # reset_running_stats()
        if self.elementwise_affine:
            nn.init.constant_(self.weight[:, :2], 1.4142135623730951)
            nn.init.zeros_(self.weight[:, 2])
            # weight储存2*2的协方差矩阵权重：前2个通道为rr，ii，后一个为ir=ri
            nn.init.zeros_(self.bias)
            #  bias保存beta的实部和虚部

    @torch.cuda.amp.autocast(enabled=False)
    def forward(self, input: torch.Tensor) -> torch.Tensor:
        """Forward.

        Args:
            input (torch.Tensor): input tensor (B, ..., *normalized_shape)

        Returns:
            ret (torch.Tensor): normalized tensor (B, ..., *normalized_shape)
        """
        # print(input.shape)

        assert input.ndim >= 2, input.ndim
        shape = (1,) * (input.ndim - len(self.normalized_shape)) + self.normalized_shape
        # Computing stats in the last len(self.normalized_shape) dims
        dim = tuple(-i for i in range(1, len(self.normalized_shape) + 1))
        # 对倒数多少个dim进行归一化统计

        # 复数均值
        mean_r = input.real.mean(dim=dim, keepdim=True).type(torch.complex64)
        mean_i = input.imag.mean(dim=dim, keepdim=True).type(torch.complex64)
        mean = mean_r + 1j * mean_i
        # x - E【x】
        input = input - mean

        # 复数方差
        Crr = input.real.var(dim=dim, keepdim=True, unbiased=False) + self.eps
        Cii = input.imag.var(dim=dim, keepdim=True, unbiased=False) + self.eps
        Cri = (input.real.mul(input.imag)).mean(dim=dim, keepdim=True)

        # calculate the inverse square root the covariance matrix
        det = Crr * Cii - Cri.pow(2)
        s = torch.sqrt(det)
        t = torch.sqrt(Cii + Crr + 2 * s)
        inverse_st = 1.0 / (s * t)
        Rrr = (Cii + s) * inverse_st
        Rii = (Crr + s) * inverse_st
        Rri = -Cri * inverse_st

        input = (Rrr * input.real + Rri * input.imag).type(torch.complex64) \
                + 1j * (Rii * input.imag + Rri * input.real).type(torch.complex64)

        if not self.elementwise_affine:
            return input

        input = (self.weight[..., 0].view(shape) * input.real + self.weight[..., 2].view(shape) * input.imag + \
                 self.bias[..., 0].view(shape)).type(torch.complex64) \
                + 1j * (self.weight[..., 2].view(shape) * input.real + self.weight[..., 1].view(shape) * input.imag + \
                        self.bias[..., 1].view(shape)).type(torch.complex64)
        del Crr, Cri, Cii, Rrr, Rii, Rri, det, s, t
        return input