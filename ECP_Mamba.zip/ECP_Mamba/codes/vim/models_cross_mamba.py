# The code of network architecture is based on Vim.
# Reference (Vim): https://github.com/hustvl/Vim

from torch import Tensor
from typing import Optional
from timm.models.layers import PatchEmbed
from codes.vim.rope import *
from codes.scan import random_scan

try:
    from mamba_ssm.ops.triton.layernorm import RMSNorm, layer_norm_fn, rms_norm_fn
except ImportError:
    RMSNorm, layer_norm_fn, rms_norm_fn = None, None, None


class Block(nn.Module):
    def __init__(
            self, dim, mixer_cls, norm_cls=nn.LayerNorm, fused_add_norm=False, residual_in_fp32=False, drop_path=0.,
    ):
        """
        Simple block wrapping a mixer class with LayerNorm/RMSNorm and residual connection"

        This Block has a slightly different structure compared to a regular
        prenorm Transformer block.
        The standard block is: LN -> MHA/MLP -> Add.
        [Ref: https://arxiv.org/abs/2002.04745]
        Here we have: Add -> LN -> Mixer, returning both
        the hidden_states (output of the mixer) and the residual.
        This is purely for performance reasons, as we can fuse add and LayerNorm.
        The residual needs to be provided (except for the very first block).
        """
        super().__init__()
        self.residual_in_fp32 = residual_in_fp32
        self.fused_add_norm = fused_add_norm
        self.mixer = mixer_cls(dim)
        self.norm = norm_cls(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        if self.fused_add_norm:
            assert RMSNorm is not None, "RMSNorm import fails"
            assert isinstance(
                self.norm, (nn.LayerNorm, RMSNorm)
            ), "Only LayerNorm and RMSNorm are supported for fused_add_norm"

    def forward(
            self, hidden_states: Tensor, residual: Optional[Tensor] = None, inference_params=None
    ):
        r"""Pass the input through the encoder layer.

        Args:
            hidden_states: the sequence to the encoder layer (required).
            residual: hidden_states = Mixer(LN(residual))
        """
        if not self.fused_add_norm:
            if residual is None:
                residual = hidden_states
            else:
                residual = residual + self.drop_path(hidden_states)

            hidden_states = self.norm(residual.to(dtype=self.norm.weight.dtype))
            if self.residual_in_fp32:
                residual = residual.to(torch.float32)
        else:
            fused_add_norm_fn = rms_norm_fn if isinstance(self.norm, RMSNorm) else layer_norm_fn
            if residual is None:
                hidden_states, residual = fused_add_norm_fn(
                    hidden_states,
                    self.norm.weight,
                    self.norm.bias,
                    residual=residual,
                    prenorm=True,
                    residual_in_fp32=self.residual_in_fp32,
                    eps=self.norm.eps,
                )
            else:
                hidden_states, residual = fused_add_norm_fn(
                    self.drop_path(hidden_states),
                    self.norm.weight,
                    self.norm.bias,
                    residual=residual,
                    prenorm=True,
                    residual_in_fp32=self.residual_in_fp32,
                    eps=self.norm.eps,
                )
        hidden_states = self.mixer(hidden_states, inference_params=inference_params)
        return hidden_states, residual

    def allocate_inference_cache(self, batch_size, max_seqlen, dtype=None, **kwargs):
        return self.mixer.allocate_inference_cache(batch_size, max_seqlen, dtype=dtype, **kwargs)


def create_block(
        d_model,
        ssm_cfg=None,
        norm_epsilon=1e-5,
        drop_path=0.,
        rms_norm=False,
        residual_in_fp32=False,
        fused_add_norm=False,
        layer_idx=None,
        device=None,
        dtype=None,
        bimamba_type="none",
):
    if ssm_cfg is None:
        ssm_cfg = {}
    factory_kwargs = {"device": device, "dtype": dtype}
    mixer_cls = partial(Mamba, layer_idx=layer_idx, bimamba_type=bimamba_type, **ssm_cfg, **factory_kwargs)
    norm_cls = partial(
        nn.LayerNorm if not rms_norm else RMSNorm, eps=norm_epsilon, **factory_kwargs
    )
    block = Block(
        d_model,
        mixer_cls,
        norm_cls=norm_cls,
        drop_path=drop_path,
        fused_add_norm=fused_add_norm,
        residual_in_fp32=residual_in_fp32,
    )
    block.layer_idx = layer_idx
    return block


# https://github.com/huggingface/transformers/blob/c28d04e9e252a1a099944e325685f14d242ecdcd/src/transformers/models/gpt2/modeling_gpt2.py#L454
def _init_weights(
        module,
        n_layer,
        initializer_range=0.02,  # Now only used for embedding layer.
        rescale_prenorm_residual=True,
        n_residuals_per_layer=1,  # Change to 2 if we have MLP
):
    if isinstance(module, nn.Linear):
        if module.bias is not None:
            if not getattr(module.bias, "_no_reinit", False):
                nn.init.zeros_(module.bias)
    elif isinstance(module, nn.Embedding):
        nn.init.normal_(module.weight, std=initializer_range)

    if rescale_prenorm_residual:
        # Reinitialize selected weights subject to the OpenAI GPT-2 Paper Scheme:
        #   > A modified initialization which accounts for the accumulation on the residual path with model depth. Scale
        #   > the weights of residual layers at initialization by a factor of 1/√N where N is the # of residual layers.
        #   >   -- GPT-2 :: https://openai.com/blog/better-language-models/
        #
        # Reference (Megatron-LM): https://github.com/NVIDIA/Megatron-LM/blob/main/megatron/model/gpt_model.py
        print(module)
        for name, p in module.named_parameters():
            if name in ["out_proj.weight", "fc2.weight"]:
                # Special Scaled Initialization --> There are 2 Layer Norms per Transformer Block
                # Following Pytorch init, except scale by 1/sqrt(2 * n_layer)
                # We need to reinit p since this code could be called multiple times
                # Having just p *= scale would repeatedly scale it down
                nn.init.kaiming_uniform_(p, a=math.sqrt(5))
                with torch.no_grad():
                    p /= math.sqrt(n_residuals_per_layer * n_layer)


def segm_init_weights(m):
    if isinstance(m, nn.Linear):
        trunc_normal_(m.weight, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.LayerNorm):
        nn.init.constant_(m.bias, 0)
        nn.init.constant_(m.weight, 1.0)


# Copyright (c) 2015-present, Facebook, Inc.
# All rights reserved.
from functools import partial
from torch import Tensor
from typing import Optional

from timm.models.vision_transformer import _cfg
from timm.models.registry import register_model
from timm.models.layers import trunc_normal_, lecun_normal_

from timm.models.layers import DropPath, to_2tuple
from timm.models.vision_transformer import _load_weights

import math

from mamba_ssm.modules.mamba_simple import Mamba

from codes.vim.rope import *
import random

try:
    from mamba_ssm.ops.triton.layernorm import RMSNorm, layer_norm_fn, rms_norm_fn
except ImportError:
    RMSNorm, layer_norm_fn, rms_norm_fn = None, None, None


class PatchEmbed(nn.Module):
    """ 2D Image to Patch Embedding
    """

    def __init__(self, img_size=32, patch_size=16, stride=16, in_chans=3, embed_dim=768, norm_layer=None, flatten=True):
        super().__init__()
        img_size = to_2tuple(img_size)
        patch_size = to_2tuple(patch_size)
        self.img_size = img_size
        self.patch_size = patch_size
        self.grid_size = ((img_size[0] - patch_size[0]) // stride + 1, (img_size[1] - patch_size[1]) // stride + 1)
        self.num_patches = self.grid_size[0] * self.grid_size[1]

        self.flatten = flatten
        self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride)
        self.norm = norm_layer(embed_dim) if norm_layer else nn.Identity()

    def forward(self, x):
        # B, C, H, W = x.shape
        # assert H == self.img_size[0] and W == self.img_size[1], \
        # f"Input image size ({H}*{W}) doesn't match model ({self.img_size[0]}*{self.img_size[1]})."

        x = self.proj(x)  # (1, 192, W, H)

        if self.flatten:  # (B, C, W, H) --> (B, N, C)
            x = x.flatten(2).transpose(1, 2)  # BCHW -> BNC

        x = self.norm(x)
        return x


class Block(nn.Module):
    def __init__(
            self, dim, mixer_cls, norm_cls=nn.LayerNorm, fused_add_norm=False, residual_in_fp32=False, drop_path=0.,
    ):
        """
        Simple block wrapping a mixer class with LayerNorm/RMSNorm and residual connection"

        This Block has a slightly different structure compared to a regular
        prenorm Transformer block.
        The standard block is: LN -> MHA/MLP -> Add.
        [Ref: https://arxiv.org/abs/2002.04745]
        Here we have: Add -> LN -> Mixer, returning both
        the hidden_states (output of the mixer) and the residual.
        This is purely for performance reasons, as we can fuse add and LayerNorm.
        The residual needs to be provided (except for the very first block).
        """
        super().__init__()
        self.residual_in_fp32 = residual_in_fp32
        self.fused_add_norm = fused_add_norm
        self.mixer = mixer_cls(dim)
        self.norm = norm_cls(dim)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        if self.fused_add_norm:
            assert RMSNorm is not None, "RMSNorm import fails"
            assert isinstance(
                self.norm, (nn.LayerNorm, RMSNorm)
            ), "Only LayerNorm and RMSNorm are supported for fused_add_norm"

    def forward(
            self, hidden_states: Tensor, residual: Optional[Tensor] = None, inference_params=None
    ):
        r"""Pass the input through the encoder layer.

        Args:
            hidden_states: the sequence to the encoder layer (required).
            residual: hidden_states = Mixer(LN(residual))
        """
        if not self.fused_add_norm:
            if residual is None:
                residual = hidden_states
            else:
                residual = residual + self.drop_path(hidden_states)

            hidden_states = self.norm(residual.to(dtype=self.norm.weight.dtype))
            if self.residual_in_fp32:
                residual = residual.to(torch.float32)
        else:
            fused_add_norm_fn = rms_norm_fn if isinstance(self.norm, RMSNorm) else layer_norm_fn
            if residual is None:
                hidden_states, residual = fused_add_norm_fn(
                    hidden_states,
                    self.norm.weight,
                    self.norm.bias,
                    residual=residual,
                    prenorm=True,
                    residual_in_fp32=self.residual_in_fp32,
                    eps=self.norm.eps,
                )
            else:
                hidden_states, residual = fused_add_norm_fn(
                    self.drop_path(hidden_states),
                    self.norm.weight,
                    self.norm.bias,
                    residual=residual,
                    prenorm=True,
                    residual_in_fp32=self.residual_in_fp32,
                    eps=self.norm.eps,
                )
        hidden_states = self.mixer(hidden_states, inference_params=inference_params)
        return hidden_states, residual

    def allocate_inference_cache(self, batch_size, max_seqlen, dtype=None, **kwargs):
        return self.mixer.allocate_inference_cache(batch_size, max_seqlen, dtype=dtype, **kwargs)


def create_block(
        d_model,
        ssm_cfg=None,
        norm_epsilon=1e-5,
        drop_path=0.,
        rms_norm=False,
        residual_in_fp32=False,
        fused_add_norm=False,
        layer_idx=None,
        device=None,
        dtype=None,
        if_bimamba=False,
        bimamba_type="none",
        if_devide_out=False,
        init_layer_scale=None,
):
    if if_bimamba:
        bimamba_type = "v1"
    if ssm_cfg is None:
        ssm_cfg = {}
    factory_kwargs = {"device": device, "dtype": dtype}
    mixer_cls = partial(Mamba, layer_idx=layer_idx, bimamba_type=bimamba_type, if_devide_out=if_devide_out,
                        init_layer_scale=init_layer_scale, **ssm_cfg, **factory_kwargs)
    norm_cls = partial(
        nn.LayerNorm if not rms_norm else RMSNorm, eps=norm_epsilon, **factory_kwargs
    )
    block = Block(
        d_model,
        mixer_cls,
        norm_cls=norm_cls,
        drop_path=drop_path,
        fused_add_norm=fused_add_norm,
        residual_in_fp32=residual_in_fp32,
    )
    block.layer_idx = layer_idx
    return block


# https://github.com/huggingface/transformers/blob/c28d04e9e252a1a099944e325685f14d242ecdcd/src/transformers/models/gpt2/modeling_gpt2.py#L454
def _init_weights(
        module,
        n_layer,
        initializer_range=0.02,  # Now only used for embedding layer.
        rescale_prenorm_residual=True,
        n_residuals_per_layer=1,  # Change to 2 if we have MLP
):
    if isinstance(module, nn.Linear):
        if module.bias is not None:
            if not getattr(module.bias, "_no_reinit", False):
                nn.init.zeros_(module.bias)
    elif isinstance(module, nn.Embedding):
        nn.init.normal_(module.weight, std=initializer_range)

    if rescale_prenorm_residual:
        # Reinitialize selected weights subject to the OpenAI GPT-2 Paper Scheme:
        #   > A modified initialization which accounts for the accumulation on the residual path with model depth. Scale
        #   > the weights of residual layers at initialization by a factor of 1/√N where N is the # of residual layers.
        #   >   -- GPT-2 :: https://openai.com/blog/better-language-models/
        #
        # Reference (Megatron-LM): https://github.com/NVIDIA/Megatron-LM/blob/main/megatron/model/gpt_model.py
        for name, p in module.named_parameters():
            if name in ["out_proj.weight", "fc2.weight"]:
                # Special Scaled Initialization --> There are 2 Layer Norms per Transformer Block
                # Following Pytorch init, except scale by 1/sqrt(2 * n_layer)
                # We need to reinit p since this code could be called multiple times
                # Having just p *= scale would repeatedly scale it down
                nn.init.kaiming_uniform_(p, a=math.sqrt(5))
                with torch.no_grad():
                    p /= math.sqrt(n_residuals_per_layer * n_layer)


def segm_init_weights(m):
    if isinstance(m, nn.Linear):
        trunc_normal_(m.weight, std=0.02)
        if isinstance(m, nn.Linear) and m.bias is not None:
            nn.init.constant_(m.bias, 0)
    elif isinstance(m, nn.Conv2d):
        # NOTE conv was left to pytorch default in my original init
        lecun_normal_(m.weight)
        if m.bias is not None:
            nn.init.zeros_(m.bias)
    elif isinstance(m, (nn.LayerNorm, nn.GroupNorm, nn.BatchNorm2d)):
        nn.init.zeros_(m.bias)
        nn.init.ones_(m.weight)


def _compute_num_patches(img_size, patches):
    return [i // p * i // p for i, p in zip(img_size, patches)]


class CrossVisionMamba(nn.Module):
    def __init__(self,
                 img_size=[16, 32],
                 patch_size=[1, 2],
                 embed_dim=[192, 384],
                 depth=[2, 2],
                 cross_depth=1,
                 channels=9,
                 num_classes=15,
                 ssm_cfg=None,
                 drop_rate=0.,
                 drop_path_rate=0.1,
                 norm_epsilon: float = 1e-5,
                 rms_norm: bool = False,
                 initializer_cfg=None,
                 fused_add_norm=False,
                 residual_in_fp32=False,
                 device=None,
                 dtype=None,
                 if_bidirectional=False,
                 final_pool_type='mean',
                 if_abs_pos_embed=False,
                 if_rope=False,
                 if_rope_residual=False,
                 flip_img_sequences_ratio=-1.,
                 if_bimamba=False,
                 bimamba_type="none",
                 if_cls_token=False,
                 if_devide_out=False,
                 init_layer_scale=None,
                 use_double_cls_token=False,
                 use_middle_cls_token=False,
                 return_features=False,
                 if_use_different_scan_strategy=False,
                 **kwargs):
        self.C = None
        factory_kwargs = {"device": device, "dtype": dtype}
        # add factory_kwargs into kwargs
        kwargs.update(factory_kwargs)
        super().__init__()
        # Bidirectional scanning is implemented in Mamba: bimamba_type == "v2"
        self.if_bidirectional = False if bimamba_type=="v2" else if_bidirectional
        self.residual_in_fp32 = residual_in_fp32
        self.fused_add_norm = fused_add_norm
        self.final_pool_type = final_pool_type
        self.if_abs_pos_embed = if_abs_pos_embed
        self.if_rope = if_rope
        self.if_rope_residual = if_rope_residual
        self.flip_img_sequences_ratio = flip_img_sequences_ratio
        self.if_cls_token = if_cls_token
        self.use_double_cls_token = use_double_cls_token
        self.use_middle_cls_token = use_middle_cls_token
        self.num_tokens = 1 if if_cls_token else 0
        self.return_features = return_features
        self.num_branches = len(img_size)

        # different scan strategy impl
        self.if_use_different_scan_strategy = if_use_different_scan_strategy
        if if_use_different_scan_strategy:
            self.scan_list = ['spiral']
            print("use_different_scan_strategy:", self.scan_list)
        else:
            self.scan_list = []

        if if_use_different_scan_strategy:
            depth = [d * len(self.scan_list) for d in depth]
            cross_depth = cross_depth * len(self.scan_list)
        if if_bidirectional:
            depth = [d * 2 for d in depth]
            cross_depth = cross_depth * 2
        self.cross_depth = cross_depth
        print("mamba branch: ", self.num_branches)
        print("mamba blocks in each branch: ", depth)
        print("cross mamba blocks in each branch: ", self.cross_depth)

        # codes parameters
        self.num_classes = num_classes
        # self.d_model = self.num_features = embed_dim  # num_features for consistency with other models
        self.d_model = self.num_features = self.embed_dim = \
            nn.ParameterList((e * len(self.scan_list)) if self.if_use_different_scan_strategy else e for e in embed_dim)

        # Multi-Scale Vision Mamba impl
        stride = patch_size
        assert len(img_size) == len(patch_size) and len(patch_size) == len(embed_dim)
        self.patch_embed = nn.ModuleList()
        num_patches = _compute_num_patches(img_size, patch_size)
        if if_abs_pos_embed:
            self.pos_drop = nn.Dropout(p=drop_rate)
            self.pos_embed = nn.ParameterList(
                [nn.Parameter(torch.zeros(1, 1 + num_patches[i], self.embed_dim[i])) for i in range(self.num_branches)])
        for im_s, p_s, e, s in zip(img_size, patch_size, embed_dim, stride):
            self.patch_embed.append(
                PatchEmbed(img_size=im_s, patch_size=p_s, in_chans=channels, stride=s, embed_dim=e, flatten=True))

        if if_cls_token:
            if use_double_cls_token:
                self.cls_token_head = \
                    nn.ParameterList(
                        [nn.Parameter(torch.zeros(1, 1, self.embed_dim[i])) for i in range(self.num_branches)])
                self.cls_token_tail = \
                    nn.ParameterList(
                        [nn.Parameter(torch.zeros(1, 1, self.embed_dim[i])) for i in range(self.num_branches)])
                self.num_tokens = 2
            else:
                self.cls_token = \
                    nn.ParameterList(
                        [nn.Parameter(torch.zeros(1, 1, self.embed_dim[i])) for i in range(self.num_branches)])
                self.num_tokens = 1

        self.drop_path = DropPath(drop_path_rate) if drop_path_rate > 0. else nn.Identity()

        # different branches of mamba blocks
        self.branches = nn.ModuleList([])
        for branch in range(self.num_branches):
            # TODO: release this comment
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, depth[branch])]  # stochastic depth decay rule
            # import ipdb;ipdb.set_trace()
            inter_dpr = [0.0] + dpr

            if depth[branch] != 0:
                layers = nn.ModuleList(
                    [
                        create_block(
                            d_model=embed_dim[branch],
                            ssm_cfg=ssm_cfg,
                            norm_epsilon=norm_epsilon,
                            rms_norm=rms_norm,
                            residual_in_fp32=residual_in_fp32,
                            fused_add_norm=fused_add_norm,
                            layer_idx=i,
                            if_bimamba=if_bimamba,
                            bimamba_type=bimamba_type,
                            drop_path=inter_dpr[i],
                            if_devide_out=if_devide_out,
                            init_layer_scale=init_layer_scale,
                            **factory_kwargs,
                        )
                        for i in range(depth[branch])
                    ]
                )
            else:
                layers = nn.ModuleList([nn.Identity() for _ in range(depth[branch])])
            self.branches.append(layers)

        # different branches of cross mamba blocks
        self.cross_branches = nn.ModuleList([])
        for branch in range(self.num_branches):
            # TODO: release this comment
            dpr = [x.item() for x in torch.linspace(0, drop_path_rate, cross_depth)]  # stochastic depth decay rule
            # import ipdb;ipdb.set_trace()
            inter_dpr = [0.0] + dpr

            if cross_depth != 0:
                layers = nn.ModuleList(
                    [
                        create_block(
                            d_model=embed_dim[branch],
                            ssm_cfg=ssm_cfg,
                            norm_epsilon=norm_epsilon,
                            rms_norm=rms_norm,
                            residual_in_fp32=residual_in_fp32,
                            fused_add_norm=fused_add_norm,
                            layer_idx=i,
                            if_bimamba=if_bimamba,
                            bimamba_type=bimamba_type,
                            drop_path=inter_dpr[i],
                            if_devide_out=if_devide_out,
                            init_layer_scale=init_layer_scale,
                            **factory_kwargs,
                        )
                        for i in range(cross_depth)
                    ])
            else:
                layers = nn.ModuleList([nn.Identity() for _ in range(depth[branch])])
            self.cross_branches.append(layers)

        # norm & output head
        self.norm_f = nn.ModuleList([(nn.LayerNorm if not rms_norm else RMSNorm)
                                     (self.embed_dim[i], eps=norm_epsilon, **factory_kwargs)
                                     for i in range(self.num_branches)])
        self.cross_norm_f = nn.ModuleList([(nn.LayerNorm if not rms_norm else RMSNorm)
                                           (self.embed_dim[i], eps=norm_epsilon, **factory_kwargs)
                                           for i in range(self.num_branches)])

        self.head = nn.ModuleList(
            [nn.Linear(self.num_features[i], num_classes) if num_classes > 0 else nn.Identity() for i in
             range(self.num_branches)]
        )

        # original init
        for i in range(self.num_branches):
            self.patch_embed[i].apply(segm_init_weights)
            self.head[i].apply(segm_init_weights)
            if if_abs_pos_embed:
                trunc_normal_(self.pos_embed[i], std=.02)
            if if_cls_token:
                if use_double_cls_token:
                    trunc_normal_(self.cls_token_head[i], std=.02)
                    trunc_normal_(self.cls_token_tail[i], std=.02)
                else:
                    trunc_normal_(self.cls_token[i], std=.02)

            # mamba block init
            self.branches[i].apply(
                partial(
                    _init_weights,
                    n_layer=depth[i],
                    **(initializer_cfg if initializer_cfg is not None else {}),
                )
            )
            # cross mamba block init
            self.cross_branches[i].apply(
                partial(
                    _init_weights,
                    n_layer=cross_depth,
                    **(initializer_cfg if initializer_cfg is not None else {}),
                )
            )

    def allocate_inference_cache(self, batch_size, max_seqlen, dtype=None, **kwargs):
        return {
            i: layer.allocate_inference_cache(batch_size, max_seqlen, dtype=dtype, **kwargs)
            for i, layer in enumerate(self.layers)
        }

    @torch.jit.ignore
    def no_weight_decay(self):
        return {"pos_embed", "cls_token", "dist_token", "cls_token_head", "cls_token_tail"}

    @torch.jit.ignore()
    def load_pretrained(self, checkpoint_path, prefix=""):
        _load_weights(self, checkpoint_path, prefix)

    def prepare_tokens(self, x, i):
        B, wh, nc = x.shape

        # add the [CLS] token to the embed patch tokens
        if self.if_cls_token:
            cls_tokens = self.cls_token[i].expand(B, -1, -1)
            x = torch.cat((cls_tokens, x), dim=1)

        # add positional encoding to each token
        x = x + self.pos_embed[i]
        return self.pos_drop(x)

    def get_intermediate_layers(self, x, n_last_block, inference_params=None, if_random_cls_token_position=False,
                                if_random_token_rank=False):
        intermediate_output = self.forward_features(x, inference_params,
                                                    if_random_cls_token_position=if_random_cls_token_position,
                                                    if_random_token_rank=if_random_token_rank,
                                                    return_intermediate_output=True)
        return intermediate_output[-n_last_block:]

    def forward_features(self, xs, inference_params=None, if_random_cls_token_position=False,
                         if_random_token_rank=False,
                         return_intermediate_output=False):
        # taken from https://github.com/rwightman/pytorch-image-models/blob/master/timm/models/vision_transformer.py
        # with modifications
        global scan_mode_num, residual, hidden_states, spiral_index
        branch_intermediate_output = []
        branch_hidden_states = []
        token_position_list = []
        cls_token_list = []

        for i in range(len(xs)):
            x = xs[i]  # x --> (B, C, W, H)
            x = self.patch_embed[i](x)
            B, M, C = x.shape  # (B, N, C)
            self.C = C

            if self.if_use_different_scan_strategy:
                x0 = x  # original x
                spiral_index = None
                for ii, scan_mode in enumerate(self.scan_list):
                    if 'spiral' in scan_mode:
                        spiral_index = ii
                    xi = random_scan(x0, scan_mode)
                    x = torch.concatenate([x, xi], dim=-1)
                x = x[..., C:]
                assert x.shape[-1] == C * len(self.scan_list), x.shape[-1]
                # spiral_index = None

            # pos encoding
            if self.if_abs_pos_embed:
                x = self.prepare_tokens(x, i)

            if self.if_cls_token:
                if self.use_double_cls_token:
                    cls_token_head = self.cls_token_head[i].expand(B, -1, -1)
                    cls_token_tail = self.cls_token_tail[i].expand(B, -1, -1)
                    token_position = [0, M + 1]
                    x = torch.cat((cls_token_head, x, cls_token_tail), dim=1)
                    M = x.shape[1]
                else:
                    if self.use_middle_cls_token:
                        if self.if_use_different_scan_strategy and spiral_index is not None:
                            # add cls token in the middle
                            # use head cls token for spiral scan
                            cls_token = self.cls_token[i].expand(B, -1, -1)
                            xx = torch.empty([B, x.shape[1] + 1, C * len(self.scan_list)], dtype=x.dtype,
                                             device=x.device)
                            token_position = [M // 2 if ii != spiral_index else M + 1 for ii in
                                              range(len(self.scan_list))]
                            for ii in range(len(token_position * C)):
                                p = token_position[ii // C]
                                xx[..., ii] = torch.cat((x[:, :p, ii], cls_token[..., ii], x[:, p:, ii]), dim=1)
                            x = xx
                        else:
                            cls_token = self.cls_token[i].expand(B, -1, -1)
                            token_position = M // 2
                            # add cls token in the middle
                            x = torch.cat((x[:, :token_position, :], cls_token, x[:, token_position:, :]), dim=1)

                    elif if_random_cls_token_position:
                        cls_token = self.cls_token[i].expand(B, -1, -1)
                        token_position = random.randint(0, M)
                        x = torch.cat((x[:, :token_position, :], cls_token, x[:, token_position:, :]), dim=1)
                        print("token_position: ", token_position)
                    else:
                        cls_token = self.cls_token[i].expand(B, -1, -1)
                        # stole cls_tokens impl from Phil Wang, thanks
                        token_position = 0
                        x = torch.cat((cls_token, x), dim=1)
                    M = x.shape[1]

            if if_random_token_rank:
                # Generate a random shuffle index
                shuffle_indices = torch.randperm(M)
                if isinstance(token_position, list):
                    print("original value: ", x[0, token_position[0], 0], x[0, token_position[1], 0])
                else:
                    print("original value: ", x[0, token_position, 0])
                print("original token_position: ", token_position)
                # Execute shuffle
                x = x[:, shuffle_indices, :]
                if isinstance(token_position, list):
                    # 找到 cls token 在 shuffle 之后的新位置
                    new_token_position = [torch.where(shuffle_indices == token_position[i])[0].item() for i in
                                          range(len(token_position))]
                    token_position = new_token_position
                else:
                    # Find the new position of the cls token after shuffle
                    token_position = torch.where(shuffle_indices == token_position)[0].item()

                if isinstance(token_position, list):
                    print("new value: ", x[0, token_position[0], 0], x[0, token_position[1], 0])
                else:
                    print("new value: ", x[0, token_position, 0])
                print("new token_position: ", token_position)

            # Mamba SSM implementation
            intermediate_output = []
            layers = self.branches[i]

            if not self.if_use_different_scan_strategy:
                residual = None
                hidden_states = x  # (B, N, C)

                if not self.if_bidirectional:
                    # Only use a single scan
                    for layer in layers:
                        hidden_states, residual = layer(
                            hidden_states, residual, inference_params=inference_params
                        )
                        intermediate_output.append(self.norm_f[i](hidden_states))
                else:
                    # Use bidirectional scanning
                    for ii in range(len(layers) // 2):
                        hidden_states_f, residual_f = layers[ii * 2](
                            hidden_states, residual, inference_params=inference_params
                        )
                        hidden_state_b, residual_b = layers[ii * 2 + 1](
                            hidden_states.flip([1]), None if residual is None else residual.flip([1]),
                            inference_params=inference_params
                        )
                        hidden_states = hidden_states_f + hidden_state_b.flip([1])
                        residual = residual_f + residual_b.flip([1])
                        intermediate_output.append(self.norm_f[i](hidden_states))

            else:  # spiral scan impl
                scan_mode_num = len(self.scan_list)
                assert len(layers) % scan_mode_num == 0, scan_mode_num

                residual_list = [None for _ in range(scan_mode_num)]
                hidden_states_list = [x[..., j * C:(j + 1) * C] for j in range(scan_mode_num)]
                layers_per_mode = len(layers) // scan_mode_num

                if not self.if_bidirectional:  # 单次扫描
                    # get same layers in a single for-loop for different scan strategy
                    for ii in range(layers_per_mode):
                        for j in range(scan_mode_num):
                            residual_j = residual_list[j]
                            hidden_states_j = hidden_states_list[j]

                            hidden_states_j, residual_j = layers[j * layers_per_mode + ii](
                                hidden_states_j, residual_j, inference_params=inference_params
                            )
                            hidden_states_list[j] = hidden_states_j
                            residual_list[j] = residual_j

                        hidden_states = torch.cat(hidden_states_list, dim=-1)
                        residual = torch.cat(residual_list, dim=-1)
                        intermediate_output.append(self.norm_f[i](hidden_states))
                else:  # 双向扫描
                    assert len(layers) % (scan_mode_num * 2) == 0, scan_mode_num
                    # get 2 same layers in a single for-loop for different scan strategies and directions
                    for ii in range(layers_per_mode // 2):
                        for j in range(scan_mode_num):
                            residual_j = residual_list[j]
                            hidden_states_j = hidden_states_list[j]

                            hidden_states_fj, residual_fj = layers[j * layers_per_mode + ii * 2](
                                hidden_states_j, residual_j, inference_params=inference_params
                            )  # forward scan
                            hidden_states_bj, residual_bj = layers[j * layers_per_mode + ii * 2 + 1](
                                hidden_states_j.flip([1]),
                                None if residual_j is None else residual_j.flip([1]),
                                inference_params=inference_params
                            )  # backward scan

                            # print(len(self.layers), layers_per_mode, j,
                            #       j * layers_per_mode + i * 2, j * layers_per_mode + i * 2 + 1)

                            hidden_states_list[j] = hidden_states_fj + hidden_states_bj.flip([1])
                            residual_list[j] = residual_fj + residual_bj.flip([1])

                        hidden_states = torch.cat(hidden_states_list, dim=-1)
                        residual = torch.cat(residual_list, dim=-1)
                        intermediate_output.append(self.norm_f[i](hidden_states))

            if return_intermediate_output:
                return branch_intermediate_output.append(intermediate_output)

            if not self.fused_add_norm:
                if residual is None:
                    residual = hidden_states
                else:
                    residual = residual + self.drop_path(hidden_states)
                hidden_states = self.norm_f[i](residual.to(dtype=self.norm_f[i].weight.dtype))
            else:
                # Set prenorm=False here since we don't need the residual
                fused_add_norm_fn = rms_norm_fn if isinstance(self.norm_f[i], RMSNorm) else layer_norm_fn
                hidden_states = fused_add_norm_fn(
                    self.drop_path(hidden_states),
                    self.norm_f[i].weight,
                    self.norm_f[i].bias,
                    eps=self.norm_f[i].eps,
                    residual=residual,
                    prenorm=False,
                    residual_in_fp32=self.residual_in_fp32,
                )
            if self.final_pool_type == 'all':
                return branch_hidden_states.append(hidden_states)

            # return sequences tokens with cls token
            if self.if_cls_token:
                branch_hidden_states.append(hidden_states)
                token_position_list.append(token_position)

                if self.use_double_cls_token:
                    cls_token_list.append(
                        (hidden_states[:, token_position[0], :] + hidden_states[:, token_position[1], :]) / 2)
                else:
                    if self.use_middle_cls_token:
                        if self.if_use_different_scan_strategy and spiral_index is not None:
                            # if 'spiral' in scan list
                            xx = torch.empty([B, C * len(self.scan_list)],
                                             dtype=hidden_states.dtype,
                                             device=hidden_states.device)
                            for ii in range(len(self.scan_list)):
                                xx[..., C * ii: C * (ii + 1)] = hidden_states[:, token_position[ii],
                                                                C * ii: C * (ii + 1)]
                            cls_token_list.append(xx)
                        else:
                            cls_token_list.append(hidden_states[:, token_position, :])
                    elif if_random_cls_token_position:
                        cls_token_list.append(hidden_states[:, token_position, :])
                    else:
                        cls_token_list.append(hidden_states[:, token_position, :])
            else:
                if self.final_pool_type == 'none':
                    branch_hidden_states.append(hidden_states[:, -1, :])
                elif self.final_pool_type == 'mean':
                    branch_hidden_states.append(hidden_states.mean(dim=1))
                elif self.final_pool_type == 'max':
                    branch_hidden_states.append(hidden_states)
                else:
                    raise NotImplementedError

        if return_intermediate_output:
            return branch_intermediate_output
        else:
            return branch_hidden_states, token_position_list, cls_token_list

    # Cress Mamba Block impl
    def cross_features(self, xs,
                       inference_params=None,
                       token_position_list=None,
                       cls_tokens_list=None,
                       return_intermediate_output=False,
                       change_cls_tokens=True, ):
        if cls_tokens_list is None:
            cls_tokens_list = []
        if token_position_list is None:
            token_position_list = []

        # cls_tokens shift via moving
        clone_xs = []
        for i in range(len(xs)):
            x = xs[i].clone()
            # cls_token in each branch moves forward one digit
            if not isinstance(token_position_list[i], list):
                x[:, token_position_list[i], :] = cls_tokens_list[i - 1]
            else:
                # if 'spiral' in scan list
                for ii in range(len(token_position_list[i])):
                    x[:, token_position_list[i][ii], ii * self.C:(ii + 1) * self.C] = cls_tokens_list[i - 1][...,
                                                                                      ii * self.C:(ii + 1) * self.C]
            clone_xs.append(x)
        xs = clone_xs

        global scan_mode_num, residual, hidden_states
        if not self.if_use_different_scan_strategy:
            residual_list = [None for _ in xs]
            hidden_states_list = xs
            if not self.if_bidirectional:
                for l in range(self.cross_depth):  # every cross_depth layer
                    for i in range(len(xs)):  # every cross branch
                        hidden_states = hidden_states_list[i]  # (B, N, C)
                        residual = residual_list[i]
                        layer = self.cross_branches[i][l]
                        hidden_states, residual = layer(
                            hidden_states, residual, inference_params=inference_params
                        )
                        hidden_states_list[i] = hidden_states

                    # cls_tokens change in every layer
                    if change_cls_tokens:
                        cls_tokens_list = [hidden_states_list[i][:, token_position_list[i], :] for i in range(len(xs))]
                        clone_hidden_states_list = []
                        for i in range(len(xs)):  # every cross branch
                            hidden_states = hidden_states_list[i].clone()
                            # 每个 branch 的 cls_tokens 向前移动一位
                            hidden_states[:, token_position_list[i], :] = cls_tokens_list[i - 1]
                            clone_hidden_states_list.append(hidden_states)
                        hidden_states_list = clone_hidden_states_list

            intermediate_output = [self.cross_norm_f[i](hidden_states_list[i]) for i in range(len(xs))]

        else:  # multi-scan impl
            scan_mode_num = len(self.scan_list)
            C = [x.shape[-1] // scan_mode_num for x in xs]
            residual_list = [[None for _ in range(scan_mode_num)] for _ in xs]
            hidden_states_list = [[xs[i][..., j * C[i]:(j + 1) * C[i]] for j in range(scan_mode_num)] for i in
                                  range(len(xs))]
            # branch list --> scan_mode list

            if not self.if_bidirectional:
                layers_per_mode = self.cross_depth // scan_mode_num
                assert self.cross_depth % scan_mode_num == 0, self.cross_depth
                for l in range(layers_per_mode):  # layers in every block
                    for i in range(len(xs)):  # every cross branch
                        for j in range(scan_mode_num):  # every scan mode
                            residual_j = residual_list[i][j]
                            hidden_states_j = hidden_states_list[i][j]
                            layer = self.cross_branches[i][j * layers_per_mode + l]
                            hidden_states_j, residual_j = layer(
                                hidden_states_j, residual_j, inference_params=inference_params
                            )
                            hidden_states_list[i][j] = hidden_states_j
                            residual_list[i][j] = residual_j

                    # cls_tokens shifting in every layer
                    if change_cls_tokens:
                        if not all(isinstance(item, list) for item in token_position_list):
                            cls_tokens_list = [
                                [hidden_states_list[i][j][:, token_position_list[i], :] for j in range(scan_mode_num)]
                                for i in range(len(xs))]
                            # branch list --> scan_mode list
                            clone_hidden_states_list = [
                                [torch.zeros_like(hidden_states_list[i][j]) for j in range(scan_mode_num)] for i in
                                range(len(xs))]
                            for i in range(len(xs)):  # every cross branch
                                for j in range(scan_mode_num):  # every scan mode
                                    hidden_states = hidden_states_list[i][j].clone()
                                    # The cls_tokens of each branch become cls_tokens of the same scan mode under the previous branch
                                    hidden_states[:, token_position_list[i], :] = cls_tokens_list[i - 1][j]
                                    clone_hidden_states_list[i][j] = hidden_states
                            hidden_states_list = clone_hidden_states_list
                        else:
                            cls_tokens_list = []
                            for i in range(len(xs)):  # i-th branch;
                                cls_tokens = []
                                token_positions = token_position_list[i]
                                for j in range(scan_mode_num):  # j-th scan mode;
                                    hidden_states_i = hidden_states[:, :, j * self.C:(j + 1) * self.C]
                                    cls_tokens.append(hidden_states_i[:, token_positions[j], :])
                                cls_tokens_list.append(cls_tokens)
                            # shift cls tokens
                            clone_hidden_states_list = [
                                [torch.zeros_like(hidden_states_list[i][j]) for j in range(scan_mode_num)] for i in
                                range(len(xs))]
                            for i in range(len(xs)):
                                token_positions = token_position_list[i]
                                for j in range(scan_mode_num):  # j-th scan mode;
                                    hidden_states = hidden_states_list[i][j].clone()
                                    # The cls_tokens of each branch become cls_tokens of the same scan mode under the previous branch
                                    hidden_states[:, token_positions[j], :] = cls_tokens_list[i - 1][j]
                                    clone_hidden_states_list[i][j] = hidden_states
                            hidden_states_list = clone_hidden_states_list

            hidden_states_list = [torch.cat(hidden_states_list[i], dim=-1) for i in range(len(xs))]
            residual_list = [torch.cat(residual_list[i], dim=-1) for i in range(len(xs))]
            intermediate_output = [self.cross_norm_f[i](hidden_states_list[i]) for i in range(len(xs))]

        if return_intermediate_output:
            return intermediate_output

        # in every branch
        global branch_hidden_states, cls_token_list
        branch_hidden_states, cls_token_list = [], []
        for i in range(len(xs)):
            hidden_states = hidden_states_list[i]
            residual = residual_list[i]
            if not self.fused_add_norm:
                if residual is None:
                    residual = hidden_states
                else:
                    residual = residual + self.drop_path(hidden_states)
                hidden_states = self.cross_norm_f[i](residual.to(dtype=self.cross_norm_f[i].weight.dtype))
            else:
                # Set prenorm=False here since we don't need the residual
                fused_add_norm_fn = rms_norm_fn if isinstance(self.cross_norm_f[i], RMSNorm) else layer_norm_fn
                hidden_states = fused_add_norm_fn(
                    self.drop_path(hidden_states),
                    self.cross_norm_f[i].weight,
                    self.cross_norm_f[i].bias,
                    eps=self.cross_norm_f[i].eps,
                    residual=residual,
                    prenorm=False,
                    residual_in_fp32=self.residual_in_fp32,
                )

            if self.final_pool_type == 'all':
                return branch_hidden_states.append(hidden_states)

            # return sequences tokens with cls token
            token_position = token_position_list[i]
            if self.if_cls_token:
                branch_hidden_states.append(hidden_states)
                if self.use_double_cls_token:
                    cls_token_list.append(
                        (hidden_states[:, token_position[0], :] + hidden_states[:, token_position[1], :]) / 2)
                else:
                    if not isinstance(token_position, list):
                        cls_token_list.append(hidden_states[:, token_position, :])
                    else:
                        cls_token_list.append(torch.cat([hidden_states[:, p, ii * self.C:(ii + 1) * self.C]
                                                         for ii, p in enumerate(token_position)], dim=-1))
            else:
                if self.final_pool_type == 'none':
                    branch_hidden_states.append(hidden_states[:, -1, :])
                elif self.final_pool_type == 'mean':
                    branch_hidden_states.append(hidden_states.mean(dim=1))
                elif self.final_pool_type == 'max':
                    branch_hidden_states.append(hidden_states)
                else:
                    raise NotImplementedError

        return branch_hidden_states, token_position_list, cls_token_list

    def forward(self, xs,
                inference_params=None,
                if_random_cls_token_position=False,
                if_random_token_rank=False, ):

        # assert len(xs) == self.num_branches
        xs, token_position, cls_tokens = self.forward_features(xs, inference_params,
                                                               if_random_cls_token_position=if_random_cls_token_position,
                                                               if_random_token_rank=if_random_token_rank,
                                                               return_intermediate_output=False)

        if self.cross_depth != 0:
            xs, token_position, cls_tokens = self.cross_features(xs=xs,
                                                                 inference_params=inference_params,
                                                                 token_position_list=token_position,
                                                                 cls_tokens_list=cls_tokens,
                                                                 return_intermediate_output=False,
                                                                 change_cls_tokens=True, )

        if self.return_features:
            return cls_tokens

        ys = []
        for i in range(len(cls_tokens)):
            x = cls_tokens[i]
            x = self.head[i](x)
            if self.final_pool_type == 'max':
                x = x.max(dim=1)[0]
            ys.append(x)
        return sum(ys) / len(ys)


@register_model
def my_cross_vim_tiny_patch16_224_bimambav2_final_pool_mean_abs_pos_embed_with_midclstok_div2(pretrained=False,
                                                                                              **kwargs):
    model = CrossVisionMamba(
        num_classes=15, img_size=[16, 32, 64], patch_size=[1, 2, 4], embed_dim=[192, 192, 192], depth=[1, 2, 3],
        cross_depth=0,
        rms_norm=True, residual_in_fp32=True,
        fused_add_norm=True, final_pool_type='mean', if_abs_pos_embed=False, if_rope=False,
        if_rope_residual=False, bimamba_type="v2", if_cls_token=True,
        if_devide_out=True, use_middle_cls_token=True,
        if_bidirectional=False, if_use_different_scan_strategy=False, **kwargs)
    model.default_cfg = _cfg()
    if pretrained:
        checkpoint = torch.hub.load_state_dict_from_url(
            url="to.do",
            map_location="cpu", check_hash=True
        )
        model.load_state_dict(checkpoint["model"])
    return model


if __name__ == "__main__":
    import torch

    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    vmamba = my_cross_vim_tiny_patch16_224_bimambav2_final_pool_mean_abs_pos_embed_with_midclstok_div2
    model = vmamba(pretrained=False).to(device)
    # print(model)

    img_size = [16, 32, 64]
    xs = [torch.randn(2, 9, img_size[i], img_size[i]).to(device) for i in range(len(img_size))]
    y = model(xs)
    print(y.shape)
