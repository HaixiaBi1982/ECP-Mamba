import ast
import os
import torch
from dataset_preparing.dataset_def import DataSet
from codes.config import configurations
from codes.test_acc_in_labeled_data import get_classification_result_on_whole_dataset
from codes.vim.models_complex_mamba import ComplexVisionMamba
from codes.vim.models_cross_mamba import CrossVisionMamba
# from codes.vim.models_mamba import VisionMamba
# from codes.vision_transformer import VisionTransformer

sub_dir = "2024-11-05_13-39-26_seed42"

# # Downstream classification settings
# parser = argparse.ArgumentParser(description='Configurations for PolSAR Classification Training')
# # training setting
# parser.add_argument('--arch', default='polsar-cross-vim', type=str,
#                     choices=['polsar-vim', 'polsar-cross-vim', 'polsar-cv-vim'])
# # PolSAR dataset setting
# parser.add_argument('--data_name', default='FlveoBig', type=str,
#                     help='Please specify the PolSAR training dataset from: FlveoBig, Flevo1991, Oberpfa, San900690.')
# parser.add_argument('--if_complex_data', default=False, type=bool, help='Whether to use complex data.')
# parser.add_argument('--image_size', default=[16, 32], type=int, help='Image Size of patch views.')
# parser.add_argument('--sampling_rate', default=1.0, type=int,
#                     help='sampling from annotated patches for training.')


if __name__ == "__main__":
    sub_dir = os.path.join(sub_dir, "checkpoint.pth")
    trained_checkpoint = torch.load(os.path.join("../classification_results", sub_dir),
                                    map_location=torch.device('cpu'))
    args = ast.literal_eval(trained_checkpoint['args'])
    net_dict = trained_checkpoint['dict']

    test_dataset = DataSet(
        dataset_path="../../benchmark_dataset/" + args.data_name,
        window_size_list=args.image_size,
        std=True,
        return_position=True,
        delete_0=False,
        complex_data=args.if_complex_data,
        sampling_rate=1.0,
    )
    class_num = test_dataset.class_num
    channels = 6 if args.if_complex_data else 9
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    print("################# Saved Settings ###################")
    for key, val in args.items():
        print("{}:  {}".format(key, val))
    print("################# Network Settings ###################")
    config = configurations[args.arch]
    for key, val in config.items():
        print("{}:  {}".format(key, val))

    if args.model_type == 'vim':
        if args.if_complex_data and args.arch == "polsar-cv-vim":
            network = ComplexVisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
        elif args.arch == "polsar-cross-vim":
            network = CrossVisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
        else:
            assert 0
            # network = VisionMamba(return_features=False, num_classes=class_num, channels=channels, **config)
    elif args.model_type == 'vit':
        assert 0
        # network = VisionTransformer(num_classes=class_num, channels=channels, **config)
    else:
        network = None

    network = network.load_state_dict(net_dict).to(device)
    get_classification_result_on_whole_dataset(
        network,
        test_dataset,
        dtype_is_complex=False,
        device=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
        save_path=None, )



