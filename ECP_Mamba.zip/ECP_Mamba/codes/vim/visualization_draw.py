import numpy as np
import matplotlib.pyplot as plt


def generate_spiral_numbers(grid_size):
    spiral = np.full((grid_size, grid_size), -1)
    num = 0
    layers = (grid_size + 1) // 2

    for layer in range(layers):
        # 顶部一行 (从左到右)
        for col in range(layer, grid_size - layer):
            spiral[layer][col] = num
            num += 1

        # 右侧一列 (从上到下)
        for row in range(layer + 1, grid_size - layer):
            spiral[row][grid_size - layer - 1] = num
            num += 1

        # 底部一行 (从右到左)
        if grid_size - layer - 1 != layer:  # 避免重复填充中间行
            for col in range(grid_size - layer - 2, layer - 1, -1):
                spiral[grid_size - layer - 1][col] = num
                num += 1

        # 左侧一列 (从下到上)
        if grid_size - layer - 1 != layer:  # 避免重复填充中间列
            for row in range(grid_size - layer - 2, layer, -1):
                spiral[row][layer] = num
                num += 1

    return np.flip(spiral, 0)


# 生成16x16的螺旋排列矩阵
grid_size = 16

# 生成按顺序排列矩阵
spiral_matrix = np.flip(np.arange(grid_size**2).reshape(grid_size, grid_size), 0) + 1
# 高亮位置列表
highlight_numbers = {9, 25, 41, 57, 73, 89, 105, 113, 114, 115, 116, 117, 118, 119, 120, 121, 121, 122,
                     123, 124, 125, 126, 127, 128, 137, 153, 169, 185, 201, 217, 233, 249
}

# highlight_numbers = {1, 18, 35, 52, 69, 86, 103, 120, 137, 154, 171, 188, 205, 222, 239, 256,
#                      16, 31, 46, 61, 76, 91, 106, 121, 136, 151, 166, 181, 196, 211, 226, 241}



# 生成螺旋排列矩阵
spiral_matrix = generate_spiral_numbers(grid_size) + 1
# 高亮位置列表
highlight_numbers = {
    1, 61, 113, 157, 193, 221, 241, 253,
    16, 74, 124, 166, 200, 226, 244, 254,
    46, 100, 146, 184, 214, 236, 250, 256,
    31, 87, 135, 175, 207, 231, 247, 255
}



center_number = 255

# 绘制网格
fig, ax = plt.subplots(figsize=(12, 10))
ax.set_xlim(0, grid_size * 30)
ax.set_ylim(0, grid_size * 30)

cell_size = 30  # 每个单元格的大小

# 绘制每个单元格
for i in range(grid_size):
    for j in range(grid_size):
        x = j * cell_size
        y = i * cell_size

        # 获取当前单元格的编号
        current_number = spiral_matrix[i, j]

        # 绘制单元格
        if current_number == center_number:
            rect = plt.Rectangle((x, y), cell_size, cell_size,
                                 edgecolor='black', facecolor='red', alpha=0.7)
        elif current_number in highlight_numbers:
            rect = plt.Rectangle((x, y), cell_size, cell_size,
                                 edgecolor='black', facecolor='yellow', alpha=0.7)
        else:
            rect = plt.Rectangle((x, y), cell_size, cell_size,
                                 edgecolor='black', facecolor='white', alpha=0.7)

        ax.add_patch(rect)

        # 添加单元格编号
        plt.text(x + cell_size / 2, y + cell_size / 2, f"{current_number}",
                 ha='center', va='center', fontsize=15)

# 设置网格线
ax.set_xticks(np.arange(0, grid_size * cell_size + 1, cell_size))
ax.set_yticks(np.arange(0, grid_size * cell_size + 1, cell_size))
ax.grid(color='black', linestyle='solid', linewidth=12)

# 隐藏坐标轴
ax.axis('off')

# plt.title("16x16回型排列图像块网格（高亮指定位置）")
plt.tight_layout()
plt.show()