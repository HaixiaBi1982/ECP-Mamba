import os
from thop import profile

os.environ["CUDA_VISIBLE_DEVICES"] = "1"

import torch
from codes.config import configurations

device = torch.device("cuda")

# Loading Network:
# 'vit' or 'multi_vit' or 'vim' or 'multi_vim' or 'cross_vim'
model_type = 'vim'

if model_type == 'cross_vim':
    from codes.vim.models_cross_mamba import CrossVisionMamba
    from codes.vim.network_summary import cross_vim_summary, mamba_flops
    config = configurations['cross-vim']
    network = CrossVisionMamba(return_features=False, num_classes=15, channels=9, **config)
elif model_type == 'multi_vim':
    from codes.vim.models_cross_mamba import CrossVisionMamba
    from codes.vim.network_summary import cross_vim_summary, mamba_flops
    config = configurations['multi-vim']
    network = CrossVisionMamba(return_features=False, num_classes=15, channels=9, **config)
elif model_type == 'vim':
    from codes.vim.models_mamba import VisionMamba
    from codes.vim.network_summary import vim_summary, mamba_flops
    config = configurations['vim']
    network = VisionMamba(return_features=False, num_classes=15, channels=9, **config)


elif model_type == 'vit':
    # import torchsummary
    from codes.vim.network_summary import vit_summary
    from codes.vision_transformer import VisionTransformer
    config = configurations['vit-t']
    network = VisionTransformer(in_chans=9, **config)
elif model_type == 'multi_vit':
    # import torchsummary
    from codes.vim.network_summary import multi_vit_summary
    from codes.vision_transformer import MultiVisionTransformer
    config = configurations['multi-vit-t']
    network = MultiVisionTransformer(in_chans=9, **config)
else:
    config = None
    network = None



print("################# Network Settings ###################")
for key, val in config.items():
    print("{}:  {}".format(key, val))



network.to(device).eval()
print(network)
if model_type == 'cross_vim' or model_type == 'multi_vim':
    model_summary = cross_vim_summary(network, [(9, 16, 16), (9, 32, 32)])
    flops, _ = mamba_flops(model_type=model_type, model=network)
elif model_type == 'vim':
    model_summary = vim_summary(network, (9, 16, 16))
    flops, _ = mamba_flops(model_type=model_type, model=network)


elif model_type == 'vit':
    model_summary = vit_summary(network, (9, 16, 16))
    input1 = torch.randn(1, 9, 16, 16).to(device)
    flops, _ = profile(network, (input1, ))
elif model_type == 'multi_vit':
    model_summary = multi_vit_summary(network, [(9, 16, 16), (9, 32, 32)])
    input1 = torch.randn(1, 9, 16, 16).to(device)
    input2 = torch.randn(1, 9, 32, 32).to(device)
    flops1, _ = profile(network.vit1, (input1, ))
    flops2, _ = profile(network.vit2, (input2, ))
    flops = flops1 + flops2 + int(network.num_classes)
else:
    model_summary = None
    flops, params = None, None


# print(model_summary)
print('FLOPs = ' + str(flops / 1000 ** 2) + 'M')