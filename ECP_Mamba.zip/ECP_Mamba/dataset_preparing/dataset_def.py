import random

import math
import numpy
import numpy as np
import torch
from matplotlib import pyplot as plt, colors
from numpy import float32, sqrt
import h5py
from torch.utils.data import Dataset
from colormap import rgb2hex

from codes.utils import seed_torch


def CropPatchesWithSlidingWindow(position, image, label_image, window_size, window_center,
                                 W_padding_ahead, H_padding_ahead):
    data_patch = numpy.zeros((image.shape[0], window_size, window_size), dtype=image.dtype)
    label_patch = numpy.zeros((window_size, window_size), dtype=label_image.dtype)
    x_center, y_center, = position[0] + W_padding_ahead, position[1] + H_padding_ahead

    for m in range(-window_center[0], window_size - window_center[0] - 1):
        for n in range(-window_center[1], window_size - window_center[1] - 1):
            data_patch[:, window_center[0] + m, window_center[1] + n] = image[:, x_center + m, y_center + n]
            label_patch[window_center[0] + m, window_center[1] + n] = label_image[x_center + m, y_center + n]

    return data_patch, label_patch


def get_mean_and_std(T):
    mean = np.zeros([T.shape[0]], dtype=T.dtype)
    std = np.zeros([T.shape[0]], dtype=T.dtype)
    for i in range(T.shape[0]):
        mean[i] = np.mean(T[i, :, :])
        if type(T[i, :, :]) == complex:
            std[i] = sqrt(((T[i, :, :] - mean) * np.conj(T[i, :, :] - mean)).sum() / np.size(T[i, :, :]))
        else:
            std[i] = np.std(T[i, :, :])
    return mean, std


class DataSet(Dataset):
    """   PolSAR dataset  """
    """ class_num: The total number of classes in the dataset """
    """ dataset_path: The folder path where the dataset is located """
    """ delete_0: Remove data without label (default label is 0) when initializing the dataset """
    """ window_size: The size of the sliding window """
    """ std: Whether the dataset is standardized or not """

    def __init__(self, dataset_path=None, delete_0=True, window_size_list=None, std=True,
                 return_position=False, complex_data=False, sampling_rate=1.0, augmentation_list=None,
                 seed=42,):
        self.dataset_path = dataset_path
        self.delete_0 = delete_0
        self.return_position = return_position
        self.window_size_list = window_size_list
        self.std = std
        self.complex_data = complex_data
        self.sampling_rate = sampling_rate
        if augmentation_list is None:
            augmentation_list = []
        self.augmentation_list = augmentation_list

        if dataset_path is not None:
            if 'Flevo1991' in dataset_path:
                self.name = 'Flevo1991'
                class_num = 14
            elif 'FlveoBig' in dataset_path:
                self.name = 'FlveoBig'
                class_num = 15
            elif 'Oberpfa' in dataset_path:
                self.name = 'Oberpfa'
                class_num = 3
            elif 'San900690' in dataset_path:
                self.name = 'San900690'
                class_num = 5
            else:
                self.name = None
                assert 0
            self.class_num = class_num

            # (T11, T12, T13, T22, T23, T33)
            total_data, total_labels = ReadData(dataset_path, std=std)
            self.total_data = total_data
            self.total_labels = total_labels
            self.shape = total_labels.shape
        else:
            self.name = None
            self.class_num = None
            self.total_data = np.zeros([6, self.shape[0], self.shape[1]])
            self.total_labels = np.zeros(self.shape)
            self.shape = (0, 0)

        if_show_whole_image = False
        if if_show_whole_image:
            draw_ground_truth(self.total_labels, self.name)
            draw_SPAN_image(self.total_data, self.name)

        # T11, T22, T33, T12, T13, T23: [6, W, H] -->
        # T11, T22, T33, real(T12), real(T13), real(T23), imag(T12), imag(T13), imag(T23)
        self.dtype = torch.complex64 if self.complex_data else torch.float32
        if not self.complex_data:
            real_data = self.total_data.real
            imag_data = self.total_data.imag[3:, ...]
            self.total_data = numpy.concatenate([real_data, imag_data], axis=0)

        # setting patch center
        self.window_center_list = []
        max_W_padding_ahead, max_H_padding_ahead, max_W_padding_behind, max_H_padding_behind = 0, 0, 0, 0
        max_index = self.window_size_list.index(max(self.window_size_list))
        for i in range(len(self.window_size_list)):
            window_size = self.window_size_list[i]
            if window_size % 2:
                W_padding_ahead = W_padding_behind = H_padding_ahead = H_padding_behind = int(window_size / 2)
                window_center = (W_padding_ahead + 1, H_padding_ahead + 1)
            else:
                W_padding_ahead = H_padding_ahead = int(window_size / 2)
                W_padding_behind = H_padding_behind = int(window_size / 2) - 1
                window_center = (W_padding_ahead, H_padding_ahead)
            self.window_center_list.append(window_center)
            if i == max_index:
                max_W_padding_ahead = W_padding_ahead
                max_H_padding_ahead = H_padding_ahead
                max_W_padding_behind = W_padding_behind
                max_H_padding_behind = H_padding_behind
        assert len(self.window_size_list) == len(self.window_center_list)
        self.max_W_padding_ahead = max_W_padding_ahead
        self.max_H_padding_ahead = max_H_padding_ahead
        # W_padding_ahead, W_padding_behind = window_center[0], window_size - window_center[0] - 1
        # H_padding_ahead, H_padding_behind = window_center[1], window_size - window_center[1] - 1


        # zero-padding
        self.padding_total_data = numpy.pad(self.total_data,
                                            (
                                                (0, 0),
                                                (max_W_padding_ahead, max_W_padding_behind),
                                                (max_H_padding_ahead, max_H_padding_behind)
                                            ),
                                            'constant',
                                            constant_values=0)
        self.padding_total_labels = numpy.pad(self.total_labels,
                                              (
                                                  (max_W_padding_ahead, max_W_padding_behind),
                                                  (max_H_padding_ahead, max_H_padding_behind)
                                              ),
                                              'constant',
                                              constant_values=0)


        # Get the position coordinates of samples on image
        if self.delete_0:
            used_data_position_before_padding = np.nonzero(self.total_labels)
        else:
            used_data_position_before_padding = np.nonzero(np.ones_like(self.total_labels))


        # Dataset Sampling
        if 0 < self.sampling_rate < 1:
            used_data_position_before_padding = self.dataset_sampling(used_data_position_before_padding, seed)
        elif self.sampling_rate == 1:
            pass
        else:
            raise ValueError(f"should 0 < sampling_rate < 1, but sampling_rate=={self.sampling_rate}.")
        self.used_data_position_before_padding = used_data_position_before_padding


        # Training set data augmentation
        self.ori_length = self.used_data_position_before_padding[0].shape[0]
        self.aug_map = [0 for _ in range(self.ori_length)]
        if len(self.augmentation_list) != 0:
            x, y = self.used_data_position_before_padding[0], self.used_data_position_before_padding[1]
            x, y = np.tile(x, len(self.augmentation_list)), np.tile(y, len(self.augmentation_list))
            self.used_data_position_before_padding = (x, y)
            for i in range(len(self.augmentation_list)):
                self.aug_map = self.aug_map + [i+1 for _ in range(self.ori_length)]
            print("dataset amount: {} --aug*{}-> {}".format(self.ori_length, len(self.augmentation_list), x.shape[0]))


    def __getitem__(self, index):
        # x = self.used_data_position_before_padding[0]
        # y = self.used_data_position_before_padding[1]
        position = (self.used_data_position_before_padding[0][index],
                    self.used_data_position_before_padding[1][index])

        data_list, label = [], None
        for i in range(len(self.window_size_list)):
            data, _ = CropPatchesWithSlidingWindow(
                position=position,
                image=self.padding_total_data,
                label_image=self.padding_total_labels,
                window_size=self.window_size_list[i],
                window_center=self.window_center_list[i],
                H_padding_ahead=self.max_H_padding_ahead,
                W_padding_ahead=self.max_W_padding_ahead,
            )

            # nparray --> torch
            data = torch.as_tensor(data, dtype=self.dtype)

            # patch augmentation
            if self.aug_map[index] != 0:
                aug = self.augmentation_list[self.aug_map[index]-1]
                data = aug(data)

            data_list.append(data)

            if i == 0:
                # When delete_0=True: classes -1-14;
                # else: 1-15 should be mapping to classes 0-14;
                # label = int(label[self.window_center_list[i]]) - 1
                label = int(self.total_labels[position]) - 1
                if (not 0 <= label <= self.class_num) and self.delete_0:
                    print(self.total_labels[position])
                    raise ValueError("Should 0 <= label <= {}, but label=={} at {}.".format(self.class_num, label, position))

                # one_hot encoding
                one_hot_label = True
                if one_hot_label:
                    label = one_hot(label, num_classes=self.class_num)
                if self.complex_data:
                    label = label * (1 + 1j)

        if self.return_position:
            return data_list, label, torch.IntTensor(position)
        else:
            return data_list, label

    def __get_mean_and_std__(self):
        # The mean and variance of all data in this dataset are obtained
        mean, std = get_mean_and_std(self.total_data)
        return mean, std

    def __get_whole_image__(self):
        # Returns the data and labels of the entire graph
        return self.total_data, self.total_labels

    def __len__(self):
        return self.used_data_position_before_padding[0].shape[0]

    def dataset_sampling(self, position_tuple, seed):
        seed_torch(seed)
        length = position_tuple[0].shape[0]
        class_num = self.class_num if self.delete_0 else self.class_num+1
        label_class_list = [[] for _ in range(class_num)]

        for i in range(length):
            position = (int(position_tuple[0][i]), int(position_tuple[1][i]))
            if self.delete_0:
                label = int(self.total_labels[position]) - 1
                assert 0 <= label <= class_num-1, label
            else:
                label = int(self.total_labels[position])
                assert 0 <= label <= class_num, label
            label_class_list[label].append(position)

        ori_num = np.zeros(class_num, dtype=int)
        sampled_num = np.zeros(class_num, dtype=int)
        for i in range(class_num):
            ori_num[i] = len(label_class_list[i])
            sampled_num[i] = int(math.ceil(self.sampling_rate * ori_num[i]))
            label_class_list[i] = random.sample(label_class_list[i], sampled_num[i])

        x, y = [], []
        for c in label_class_list:
            for p in c:
                x.append(p[0])
                y.append(p[1])
        sampled_position_tuple = (np.array(x), np.array(y))

        print("-" * 30)
        if self.sampling_rate > 1:
            print("sampling_num_of_each_class={} ori_data_num:{} --> used_data_num:{}".format(self.sampling_rate, np.sum(ori_num), np.sum(sampled_num)))
        elif 0 < self.sampling_rate < 1:
            print("sampling_rate={:.2%} ori_data_num:{} --> used_data_num:{}".format(self.sampling_rate, np.sum(ori_num), np.sum(sampled_num)))
        else:
            assert 0

        for i in range(class_num):
            if self.delete_0:
                class_str = "class" + str(i + 1)
            else:
                class_str = "background" if i==0 else "class" + str(i)
            print(class_str + f" number: {ori_num[i]} --> {sampled_num[i]};")
        print("-" * 30)
        return sampled_position_tuple

def one_hot(label, num_classes):
    ones = torch.eye(num_classes)
    onehot = ones[label, :]
    return onehot.clone().detach()


def standardization(data):
    mean = numpy.mean(data)
    if type(data) == complex:
        std = sqrt(((data - mean) * numpy.conj(data - mean)).sum() / numpy.size(data))
    else:
        std = numpy.std(data)
    return (data - mean) / std


def load_matrix_from_file(file_path, load_list, shape, dtype, San900690=False):
    data_list = []
    for i in range(len(load_list)):
        load_path = file_path + load_list[i]
        data = ReadFile(load_path, shape, San900690)
        data_list.append(data)
    T11 = data_list[0]
    T12 = data_list[1] + 1j * data_list[2]
    T13 = data_list[3] + 1j * data_list[4]
    T22 = data_list[5]
    T23 = data_list[6] + 1j * data_list[7]
    T33 = data_list[8]
    return T11.astype(dtype), T12.astype(dtype), T13.astype(dtype), T22.astype(dtype), T23.astype(dtype), T33.astype(
        dtype)


def ReadFile(filepath, shape, San900690):
    """ Read each element of the T-matrix in the data set """
    data = numpy.fromfile(filepath, dtype=float32)
    if San900690:
        data = data.reshape((shape[0] * 2, shape[1] * 2))
        data = data[0:data.shape[0] - 1:2, 0:data.shape[1] - 1:2]
    else:
        data = data.reshape(shape)
    return data


def ReadFileFlveoBig(filepath):
    data = np.fromfile(filepath, dtype=float32)
    data = data.reshape(750, 1024)
    return data


from scipy.io import loadmat

def ReadData(dataset_path, std=True, dtype=numpy.complex64):
    """  Read PolSAR data  """
    """  std: Whether to perform Z-Score standardization  """
    """  dtype: output data type (plural np.plex64)  """

    global T11, T12, T13, T22, T23, T33, GT

    if 'FlveoBig' in dataset_path:
        # FlveoBig：750*1024

        GT = h5py.File(dataset_path + "/label.mat", 'r')
        GT = GT['label'][:]
        # 取出主键为data的所有的键值

        bin_path = dataset_path + '/LEE_T3/T11.bin'
        T11 = ReadFileFlveoBig(bin_path)
        T11 = T11.transpose(1, 0)

        bin_path = dataset_path + '/LEE_T3/T12_imag.bin'
        T12_imag = ReadFileFlveoBig(bin_path)
        bin_path = dataset_path + '/LEE_T3/T12_real.bin'
        T12_real = ReadFileFlveoBig(bin_path)
        T12 = T12_real + 1j * T12_imag
        T12 = T12.transpose(1, 0)

        bin_path = dataset_path + '/LEE_T3/T13_imag.bin'
        T13_imag = ReadFileFlveoBig(bin_path)
        bin_path = dataset_path + '/LEE_T3/T13_real.bin'
        T13_real = ReadFileFlveoBig(bin_path)
        T13 = T13_real + 1j * T13_imag
        T13 = T13.transpose(1, 0)

        bin_path = dataset_path + '/LEE_T3/T22.bin'
        T22 = ReadFileFlveoBig(bin_path)
        T22 = T22.transpose(1, 0)

        bin_path = dataset_path + '/LEE_T3/T23_imag.bin'
        T23_imag = ReadFileFlveoBig(bin_path)
        bin_path = dataset_path + '/LEE_T3/T23_real.bin'
        T23_real = ReadFileFlveoBig(bin_path)
        T23 = T23_real + 1j * T23_imag
        T23 = T23.transpose(1, 0)

        bin_path = dataset_path + '/LEE_T3/T33.bin'
        T33 = ReadFileFlveoBig(bin_path)
        T33 = T33.transpose(1, 0)
    elif 'Flevo1991' in dataset_path:  # Flevo1991：1020*1024
        GT = loadmat(dataset_path + "/GT_Flevo1991_14C.mat")
        GT = GT['label'][:]

        data_mat_path = dataset_path + "/T.mat"
        data = loadmat(data_mat_path)
        T11 = data['T11'][:].astype(dtype)
        T12 = data['T12'][:].astype(dtype)
        T13 = data['T13'][:].astype(dtype)
        T22 = data['T22'][:].astype(dtype)
        T23 = data['T23'][:].astype(dtype)
        T33 = data['T33'][:].astype(dtype)
    elif 'Oberpfa' in dataset_path:  # Oberpfa: 1300*1200
        GT = loadmat(dataset_path + "/GT_Oberpfa_3C.mat")
        GT = GT['label'][:]  # #取出主键为data的所有的键值

        load_list = ["T11.bin", 'T12_imag.bin', "T12_real.bin", "T13_imag.bin", "T13_real.bin", "T22.bin",
                     "T23_imag.bin", "T23_real.bin", "T33.bin"]
        data_mat_path = dataset_path + "/LEE_T3/"
        T11, T12, T13, T22, T23, T33 = load_matrix_from_file(data_mat_path, load_list, GT.shape, dtype)

    elif 'San900690' in dataset_path:  # San900690: 1800*1380
        GT = loadmat(dataset_path + "/GT_Sanfran_5Classes.mat")
        GT = GT['GT'][:]  # #取出主键为data的所有的键值

        load_list = ["T11.bin", 'T12_imag.bin', "T12_real.bin", "T13_imag.bin", "T13_real.bin", "T22.bin",
                     "T23_imag.bin", "T23_real.bin", "T33.bin"]
        data_mat_path = dataset_path + "/LEE_T3/"
        T11, T12, T13, T22, T23, T33 = load_matrix_from_file(data_mat_path, load_list, GT.shape, dtype, San900690=True)
    else:
        raise ValueError("dataset_path should include 'Flevo1991' or 'FlveoBig' or 'Oberpfa' or 'San900690.")

    if std:
        # 是否对T矩阵的输入参数进行标准化
        T11 = standardization(T11)
        T12 = standardization(T12)
        T13 = standardization(T13)
        T22 = standardization(T22)
        T23 = standardization(T23)
        T33 = standardization(T33)

    T_matrix = numpy.dstack((T11, T22, T33, T12, T13, T23,))
    T_matrix = numpy.transpose(T_matrix, (2, 0, 1))

    if 'FlveoBig' in dataset_path:
        GT = numpy.flip(GT, 1)
        T_matrix = numpy.flip(T_matrix, -1)
    elif 'Flevo1991' in dataset_path:
        GT = numpy.rot90(GT, k=3)
        T_matrix = numpy.rot90(T_matrix, k=1, axes=(-1, -2))
    elif 'Oberpfa' in dataset_path:
        GT = numpy.rot90(GT, k=3)
        T_matrix = numpy.rot90(T_matrix, k=1, axes=(-1, -2))
    elif 'San900690' in dataset_path:
        GT = np.rot90(np.flip(GT, 1))
        T_matrix = np.rot90(T_matrix, k=1, axes=(-1, -2))

    return T_matrix, GT

def set_colors_bar(dataset_name):
    """Set color bar"""
    global colors_list, label_list, sm

    if "FlveoBig" in dataset_name:
        colors_list = \
            ['white', rgb2hex(0, 0, 225), 'darkred', 'indigo',
             'red', 'm', 'forestgreen', 'darkgoldenrod', 'lime',
             'orange', 'cyan', rgb2hex(220, 208, 255),
             'pink', 'navajowhite', 'yellow', 'lightgreen']
    elif "Flevo1991" in dataset_name:
        colors_list = ['white',
                       rgb2hex(255, 128, 0), rgb2hex(138, 42, 166), rgb2hex(0, 0, 255),
                       rgb2hex(255, 0, 0), rgb2hex(120, 178, 215), rgb2hex(0, 102, 205),
                       rgb2hex(251, 232, 45), rgb2hex(0, 255, 0), rgb2hex(204, 102, 255),
                       rgb2hex(0, 204, 102), rgb2hex(204, 255, 204), rgb2hex(204, 0, 102),
                       rgb2hex(255, 204, 204), rgb2hex(102, 0, 204)]
    elif "Oberpfa" in dataset_name:
        colors_list = ['white', rgb2hex(255, 0, 0), rgb2hex(0, 255, 0), rgb2hex(255, 255, 0)]
    elif "San900690" in dataset_name:
        colors_list = [
                       'white',
                       rgb2hex(0, 0, 1, True),  # 蓝色
                       rgb2hex(0, 1, 0, True),  # 绿色
                       rgb2hex(1, 0, 1, True),  # 紫色
                       rgb2hex(1, 0, 0, True),  # 红色
                       rgb2hex(1, 1, 0, True),  # 黄色
                       ]
    else:
        assert 0, dataset_name

    # # It is used to display Chinese labels properly
    # plt.rcParams['font.sans-serif'] = ['SimHei']
    c_map = colors.LinearSegmentedColormap.from_list('mylist', colors_list, N=len(colors_list))
    sm = plt.cm.ScalarMappable(cmap=c_map)
    return sm, c_map


def draw_ground_truth(GT, dataset_name):
    x = numpy.arange(GT.shape[0])
    y = numpy.arange(GT.shape[1])
    x, y = numpy.meshgrid(x, y)
    z = GT[x, y]
    sm, c_map = set_colors_bar(dataset_name)

    plt.figure(figsize=(GT.shape[0] / 100, GT.shape[1] / 100))
    plt.pcolor(x, y, z, cmap=c_map)
    plt.title("{}\nImage size：{}\n".format(dataset_name, GT.shape), fontsize=20)

    ax = plt.gca()
    ax.axes.xaxis.set_ticks([])
    ax.axes.yaxis.set_ticks([])
    plt.grid(True)

    plt.show()


from PIL import Image
def draw_SPAN_image(image, dataset_name):
    SPAN = abs((image[0, :, :]) + (image[1, :, :]) + (image[2, :, :]))
    SPAN = standardization(SPAN)
    SPAN = SPAN * 255  # 变换为0-255的灰度值
    im = Image.fromarray(SPAN)
    im = im.convert('L').transpose(Image.ROTATE_90)  # 这样才能转为灰度图，如果是彩色图则改L为‘RGB’
    plt.figure(figsize=(GT.shape[0] / 100, GT.shape[1] / 100))
    plt.title("{}---SPAN\n图像大小：{}\n".format(dataset_name, GT.shape), fontsize=20)
    plt.imshow(im)
    plt.show()
